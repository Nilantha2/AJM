package com.example.studentattendance

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.studentattendance.ui.screens.MainScreen
import com.example.studentattendance.ui.theme.StudentAttendanceTheme
import com.example.studentattendance.ui.viewmodel.AttendanceViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: AttendanceViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            StudentAttendanceTheme {
                MainScreen(viewModel = viewModel)
            }
        }
    }
}

