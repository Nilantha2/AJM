package com.example.studentattendance.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.studentattendance.R
import com.example.studentattendance.data.local.AttendanceEntity
import com.example.studentattendance.data.local.StudentEntity
import com.example.studentattendance.data.repository.AttendanceRepository
import com.example.studentattendance.ui.theme.*
import java.io.File

@Composable
fun AppHeader(
    schoolName: String,
    todayDate: String,
    morningStartTime: String = "06:30",
    attendanceCutoffTime: String = "07:30",
    schoolLogoUrl: String = "https://i.imgur.com/ZcvAfkf.png",
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("app_header_card"),
        shape = RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp),
        colors = CardDefaults.cardColors(
            containerColor = SchoolPrimary
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF032538),
                            Color(0xFF1E3A8A),
                            Color(0xFF10B981)
                        )
                    )
                )
                .padding(horizontal = 20.dp, vertical = 22.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // School crest avatar / user's logo
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .border(3.dp, Color(0xFF60A5FA), CircleShape)
                        .shadow(8.dp, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = ImageRequest.Builder(LocalContext.current)
                            .data(if (schoolLogoUrl.isNotBlank()) schoolLogoUrl else R.drawable.app_logo)
                            .placeholder(R.drawable.app_logo)
                            .error(R.drawable.app_logo)
                            .crossfade(true)
                            .build(),
                        contentDescription = "School Logo",
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(4.dp)
                            .clip(CircleShape),
                        contentScale = ContentScale.Fit
                    )
                }

                Text(
                    text = "සිසුන් පැමිණීමේ ලේඛනය",
                    color = Color.White,
                    fontSize = 20.dp.value.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = schoolName,
                    color = Color(0xFFFDE68A),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center
                )

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color.White.copy(alpha = 0.22f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.4f))
                    ) {
                        Text(
                            text = "📅 $todayDate",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                            maxLines = 1
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color(0xFF0F172A).copy(alpha = 0.4f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF34D399).copy(alpha = 0.6f))
                    ) {
                        Text(
                            text = "⏰ නියමිත වේලාව: $morningStartTime – $attendanceCutoffTime",
                            color = Color(0xFFD1FAE5),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SchoolTimetableCard(
    morningStartTime: String = "06:30",
    cutoffTime: String = "07:30",
    lateCutoffTime: String = "08:00",
    schoolEndTime: String = "13:30",
    currentTime: String,
    modifier: Modifier = Modifier
) {
    val curTimeShort = currentTime.take(5)

    val isMorningEntry = curTimeShort >= morningStartTime && curTimeShort < cutoffTime
    val isLateEntry = curTimeShort >= cutoffTime && curTimeShort < lateCutoffTime
    val isAcademicSession = curTimeShort >= lateCutoffTime && curTimeShort < schoolEndTime
    val isSchoolEnded = curTimeShort >= schoolEndTime || (curTimeShort.isNotBlank() && curTimeShort < morningStartTime)

    val activeStatusText = when {
        isMorningEntry -> "🟢 දැන් ක්‍රියාත්මකයි: සාමාන්‍ය පැමිණීම (On-Time Entry Window)"
        isLateEntry -> "🟠 දැන් ක්‍රියාත්මකයි: ප්‍රමාද පැමිණීම (Late Entry Window)"
        isAcademicSession -> "📚 දැන් ක්‍රියාත්මකයි: අධ්‍යයන සැසිය (School In Session)"
        else -> "⚪ පාසල් වේලාවෙන් බැහැරයි (School Closed / After Hours)"
    }
    val activeBadgeColor = when {
        isMorningEntry -> SchoolAccentGreen
        isLateEntry -> LateOrange
        isAcademicSession -> SchoolPrimaryLight
        else -> SlateMuted
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("school_timetable_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFEFF6FF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = "Timetable",
                            tint = SchoolPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "⏰ පාසල් පැමිණීමේ කාලසටහන",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = SlateDark
                        )
                        Text(
                            text = "School Attendance Timetable",
                            fontSize = 11.sp,
                            color = SlateMuted
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = activeBadgeColor.copy(alpha = 0.12f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, activeBadgeColor.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = if (isMorningEntry) "නියමිතයි" else if (isLateEntry) "ප්‍රමාදයි" else if (isAcademicSession) "සැසිය" else "නිමාව",
                        color = activeBadgeColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Status Banner
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = activeBadgeColor.copy(alpha = 0.08f),
                border = androidx.compose.foundation.BorderStroke(1.dp, activeBadgeColor.copy(alpha = 0.25f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = activeStatusText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = activeBadgeColor
                    )
                }
            }

            // Timetable Grid (4 slots)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TimetableSlotItem(
                        icon = "🌅",
                        title = "සාමාන්‍ය පැමිණීම",
                        timeRange = "$morningStartTime - $cutoffTime",
                        statusText = "නියමිතයි (On-Time)",
                        isActive = isMorningEntry,
                        activeColor = SchoolAccentGreen,
                        bgColor = Color(0xFFECFDF5),
                        modifier = Modifier.weight(1f)
                    )
                    TimetableSlotItem(
                        icon = "⚠️",
                        title = "ප්‍රමාද පැමිණීම",
                        timeRange = "$cutoffTime - $lateCutoffTime",
                        statusText = "ප්‍රමාදයි (Late)",
                        isActive = isLateEntry,
                        activeColor = LateOrange,
                        bgColor = Color(0xFFFFFBEB),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TimetableSlotItem(
                        icon = "📚",
                        title = "අධ්‍යයන සැසිය",
                        timeRange = "$lateCutoffTime - $schoolEndTime",
                        statusText = "පාසල් කාලය (Classes)",
                        isActive = isAcademicSession,
                        activeColor = SchoolPrimaryLight,
                        bgColor = Color(0xFFEFF6FF),
                        modifier = Modifier.weight(1f)
                    )
                    TimetableSlotItem(
                        icon = "🔔",
                        title = "පාසල විසිර යාම",
                        timeRange = "$schoolEndTime (01:30 PM)",
                        statusText = "පාසල් නිමාව (End)",
                        isActive = isSchoolEnded && curTimeShort >= schoolEndTime,
                        activeColor = Color(0xFF8B5CF6),
                        bgColor = Color(0xFFF5F3FF),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
fun TimetableSlotItem(
    icon: String,
    title: String,
    timeRange: String,
    statusText: String,
    isActive: Boolean,
    activeColor: Color,
    bgColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = if (isActive) bgColor else Color(0xFFF8FAFC),
        border = androidx.compose.foundation.BorderStroke(
            width = if (isActive) 2.dp else 1.dp,
            color = if (isActive) activeColor else SlateBorder
        ),
        shadowElevation = if (isActive) 3.dp else 0.dp
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = icon, fontSize = 16.sp)
                if (isActive) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = activeColor
                    ) {
                        Text(
                            text = "දැන් සක්‍රියයි",
                            color = Color.White,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = SlateDark
            )

            Text(
                text = timeRange,
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (isActive) activeColor else Color(0xFF334155),
                fontFamily = FontFamily.Monospace
            )

            Text(
                text = statusText,
                fontSize = 10.sp,
                color = if (isActive) activeColor else SlateMuted,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun DigitalClock3D(
    timeString: String,
    modifier: Modifier = Modifier
) {
    val parts = timeString.split(":")
    val hours = parts.getOrNull(0) ?: "07"
    val minutes = parts.getOrNull(1) ?: "00"
    val seconds = parts.getOrNull(2) ?: "00"

    Surface(
        modifier = modifier.testTag("digital_clock_display"),
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF0F172A),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF38BDF8).copy(alpha = 0.7f)),
        shadowElevation = 3.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Schedule,
                contentDescription = null,
                tint = Color(0xFFF59E0B),
                modifier = Modifier.size(15.dp)
            )

            Text(
                text = "$hours:$minutes:$seconds",
                color = Color(0xFF38BDF8),
                fontSize = 14.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp,
                softWrap = false,
                maxLines = 1
            )
        }
    }
}

@Composable
fun LiveStatsDashboard(
    onTimeBoys: Int,
    onTimeGirls: Int,
    lateBoys: Int,
    lateGirls: Int,
    currentTime: String,
    morningStartTime: String = "06:30",
    cutoffTime: String = "07:30",
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("live_stats_dashboard"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(SchoolAccentGreen)
                    )
                    Text(
                        text = "📊 සජීවී සංඛ්‍යාලේඛන",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = SlateDark,
                        maxLines = 1
                    )
                }

                DigitalClock3D(timeString = currentTime)
            }

            // 2x2 Grid of Live Stat Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                LiveStatCard(
                    icon = "👦",
                    count = onTimeBoys,
                    label = "නියමිත පිරිමි",
                    subLabel = "($morningStartTime-$cutoffTime)",
                    numberColor = BoysBlue,
                    bgColor = BoysBlueLight,
                    borderColor = BoysBlueBorder,
                    modifier = Modifier.weight(1f)
                )
                LiveStatCard(
                    icon = "👧",
                    count = onTimeGirls,
                    label = "නියමිත ගැහැණු",
                    subLabel = "($morningStartTime-$cutoffTime)",
                    numberColor = GirlsPink,
                    bgColor = GirlsPinkLight,
                    borderColor = GirlsPinkBorder,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                LiveStatCard(
                    icon = "👦",
                    count = lateBoys,
                    label = "ප්‍රමාද පිරිමි",
                    subLabel = "($cutoffTime+)",
                    numberColor = LateOrange,
                    bgColor = LateOrangeLight,
                    borderColor = LateOrangeBorder,
                    modifier = Modifier.weight(1f)
                )
                LiveStatCard(
                    icon = "👧",
                    count = lateGirls,
                    label = "ප්‍රමාද ගැහැණු",
                    subLabel = "($cutoffTime+)",
                    numberColor = LateRed,
                    bgColor = LateRedLight,
                    borderColor = LateRedBorder,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun LiveStatCard(
    icon: String,
    count: Int,
    label: String,
    subLabel: String,
    numberColor: Color,
    bgColor: Color,
    borderColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.testTag("stat_card_${label}"),
        shape = RoundedCornerShape(16.dp),
        color = bgColor,
        border = androidx.compose.foundation.BorderStroke(2.dp, borderColor),
        shadowElevation = 2.dp
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = icon,
                fontSize = 28.sp
            )

            Column {
                Text(
                    text = count.toString(),
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = numberColor
                )
                Text(
                    text = label,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = SlateDark
                )
                Text(
                    text = subLabel,
                    fontSize = 9.sp,
                    color = SlateMuted
                )
            }
        }
    }
}

@Composable
fun TopArrivalsPodium(
    top3Arrivals: List<AttendanceEntity>,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("top_arrivals_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "🏆 අද ප්‍රථමයින් පැමිණි සිසුන්",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = SlateDark,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // 1st place
                val first = top3Arrivals.getOrNull(0)
                PodiumCard(
                    medal = "🥇",
                    name = first?.studentName ?: "-",
                    time = first?.time ?: "-",
                    borderColor = GoldMedal,
                    bgColor = Color(0xFFFEF9C3),
                    modifier = Modifier.weight(1f)
                )

                // 2nd place
                val second = top3Arrivals.getOrNull(1)
                PodiumCard(
                    medal = "🥈",
                    name = second?.studentName ?: "-",
                    time = second?.time ?: "-",
                    borderColor = SilverMedal,
                    bgColor = Color(0xFFF1F5F9),
                    modifier = Modifier.weight(1f)
                )

                // 3rd place
                val third = top3Arrivals.getOrNull(2)
                PodiumCard(
                    medal = "🥉",
                    name = third?.studentName ?: "-",
                    time = third?.time ?: "-",
                    borderColor = BronzeMedal,
                    bgColor = Color(0xFFFFEDD5),
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun PodiumCard(
    medal: String,
    name: String,
    time: String,
    borderColor: Color,
    bgColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = bgColor,
        border = androidx.compose.foundation.BorderStroke(2.dp, borderColor)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(text = medal, fontSize = 26.sp)

            Text(
                text = name,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = SlateDark,
                textAlign = TextAlign.Center,
                maxLines = 1
            )

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color.White.copy(alpha = 0.85f),
                border = androidx.compose.foundation.BorderStroke(1.dp, borderColor.copy(alpha = 0.4f))
            ) {
                Text(
                    text = if (time != "-") "🕐 $time" else "-",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = SlateDark,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }
    }
}

@Composable
fun FingerprintScannerBox(
    isScanning: Boolean,
    statusText: String,
    onScanClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "fingerprint_glow")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(6000, easing = LinearEasing)
        ),
        label = "rotation"
    )
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("fingerprint_scanner_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "👆 ඇඟිලි සලකුණ තබන්න",
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = SlateDark
            )

            Text(
                text = "පැමිණීම සටහන් කිරීමට ස්කෑනරය ස්පර්ශ කරන්න",
                fontSize = 13.sp,
                color = SlateMuted,
                textAlign = TextAlign.Center
            )

            // Touch scanner button
            Box(
                modifier = Modifier
                    .size(140.dp)
                    .scale(if (isScanning) pulseScale else 1f)
                    .clip(CircleShape)
                    .background(
                        Brush.sweepGradient(
                            listOf(
                                SchoolPrimary,
                                SchoolPrimaryLight,
                                Color(0xFF00F2FE),
                                SchoolAccentGreen,
                                SchoolPrimary
                            )
                        )
                    )
                    .rotate(if (isScanning) rotation else 0f)
                    .clickable { onScanClick() }
                    .testTag("fingerprint_scanner_button"),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(118.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF1E3A8A),
                                    Color(0xFF2563EB)
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Fingerprint,
                        contentDescription = "Fingerprint Scanner",
                        tint = Color.White,
                        modifier = Modifier.size(68.dp)
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isScanning) Color(0xFFEFF6FF) else Color(0xFFF1F5F9),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isScanning) Color(0xFF3B82F6) else SlateBorder
                )
            ) {
                Text(
                    text = statusText,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (isScanning) Color(0xFF1E40AF) else SlateDark,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }
    }
}

@Composable
fun ScannedStudentDetailCard(
    student: StudentEntity,
    record: AttendanceEntity?,
    onNewScanClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isOnTime = record?.isOnTime ?: true

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("student_details_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        border = androidx.compose.foundation.BorderStroke(
            2.dp,
            if (isOnTime) SchoolAccentGreen else LateOrange
        )
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Fingerprint verified badge with clear vector icon and well-formatted text
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isOnTime) Color(0xFFECFDF5) else Color(0xFFFFFBEB),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isOnTime) Color(0xFFA7F3D0) else Color(0xFFFDE68A)
                )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Fingerprint,
                        contentDescription = "Fingerprint",
                        tint = if (isOnTime) SchoolAccentGreen else LateOrange,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = if (student.faceData.isNotBlank()) "5-Scan තහවුරු කළ ඇඟිලි සලකුණ" else "ඇඟිලි සලකුණෙන් හඳුනා ගන්නා ලදී",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isOnTime) SchoolAccentGreen else LateOrange
                    )
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Verified",
                        tint = if (isOnTime) SchoolAccentGreen else LateOrange,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }

            // Student avatar
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(if (student.gender == "female") GirlsPinkLight else BoysBlueLight)
                    .border(3.dp, if (isOnTime) SchoolAccentGreen else LateOrange, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (student.photo.isNotBlank()) {
                    AsyncImage(
                        model = student.photo,
                        contentDescription = student.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Text(
                        text = student.name.take(1),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (student.gender == "female") GirlsPink else BoysBlue
                    )
                }
            }

            Text(
                text = student.name,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold,
                color = SlateDark
            )

            // Info rows: ONLY this specific student's information
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DetailRow(label = "🆔 හැඳුනුම්පත් අංකය (ID)", value = student.id)
                DetailRow(label = "🎓 ශ්‍රේණිය (Grade)", value = student.grade)
                DetailRow(
                    label = "👤 ස්ත්‍රී / පුරුෂ භාවය",
                    value = if (student.gender == "female") "ගැහැණු (Female)" else "පිරිමි (Male)"
                )
                if (student.faceData.isNotBlank()) {
                    DetailRow(
                        label = "🔒 ඇඟිලි සලකුණු තත්ත්වය",
                        value = "5-Scan තහවුරුයි",
                        isBadge = true,
                        badgeColor = SchoolAccentGreen,
                        badgeText = "✓ 5-Scan Verified (100%)"
                    )
                }
                DetailRow(
                    label = "⏰ පැමිණි වේලාව",
                    value = record?.time ?: "-",
                    isBadge = true,
                    badgeColor = if (isOnTime) SchoolAccentGreen else LateOrange,
                    badgeText = if (isOnTime) "නියමිත වේලාව (${record?.time})" else "ප්‍රමාදයි (${record?.time})"
                )
                DetailRow(label = "📅 දිනය", value = record?.date ?: AttendanceRepository.getTodayDateString())
                if (student.whatsapp.isNotBlank()) {
                    DetailRow(
                        label = "💬 WhatsApp දැනුම්දීම",
                        value = "දෙමාපියන්ට යවන ලදී",
                        isBadge = true,
                        badgeColor = SchoolAccentGreen,
                        badgeText = "✅ යවන ලදී (${student.whatsapp})"
                    )
                }
            }

            Button(
                onClick = onNewScanClick,
                colors = ButtonDefaults.buttonColors(containerColor = SchoolPrimary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("new_scan_button")
            ) {
                Icon(imageVector = Icons.Default.Refresh, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("🔄 ඊළඟ සිසුවා ස්කෑන් කරන්න (Next Scan)", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun DetailRow(
    label: String,
    value: String,
    isBadge: Boolean = false,
    badgeColor: Color = SchoolAccentGreen,
    badgeText: String = ""
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFF8FAFC), RoundedCornerShape(8.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 13.sp,
            color = SlateMuted,
            fontWeight = FontWeight.Medium
        )

        if (isBadge) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = badgeColor.copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(1.dp, badgeColor)
            ) {
                Text(
                    text = badgeText,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = badgeColor,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        } else {
            Text(
                text = value,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = SlateDark
            )
        }
    }
}
