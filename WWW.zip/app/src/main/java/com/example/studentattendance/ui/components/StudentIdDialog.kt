package com.example.studentattendance.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.studentattendance.data.local.StudentEntity
import com.example.studentattendance.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun StudentIdDialog(
    students: List<StudentEntity>,
    onDismiss: () -> Unit,
    onStudentSelected: (String) -> Unit
) {
    var idInput by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isFingerprintScanning by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()
    val trimmedInput = idInput.trim()
    val matchedStudent = remember(trimmedInput, students) {
        if (trimmedInput.isEmpty()) null
        else students.find { it.id.equals(trimmedInput, ignoreCase = true) }
    }

    val scrollState = rememberScrollState()

    // Animation for fingerprint touch
    val infiniteTransition = rememberInfiniteTransition(label = "dialog_fp_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "fp_pulse"
    )

    fun performVerify() {
        if (trimmedInput.isEmpty()) {
            errorMessage = "කරුණාකර සිසුවාගේ හැඳුනුම්පත් අංකය ඇතුළත් කරන්න!"
        } else if (matchedStudent != null) {
            errorMessage = null
        } else {
            errorMessage = "'$trimmedInput' අංකයට අදාළ සිසුවෙකු ලියාපදිංචි වී නොමැත."
        }
    }

    fun triggerFingerprintTouch() {
        coroutineScope.launch {
            isFingerprintScanning = true
            errorMessage = null
            delay(750)
            isFingerprintScanning = false

            if (matchedStudent != null) {
                // Verified specific student via fingerprint!
                errorMessage = null
            } else if (trimmedInput.isNotEmpty()) {
                errorMessage = "'$trimmedInput' අංකයට අදාළ සිසුවෙකු ලියාපදිංචි වී නොමැත."
            } else {
                // If input is empty, automatically match the enrolled biometric fingerprint
                val enrolledWithFp = students.filter { it.faceData.isNotBlank() }
                if (enrolledWithFp.isNotEmpty()) {
                    idInput = enrolledWithFp.first().id
                    errorMessage = null
                } else if (students.isNotEmpty()) {
                    idInput = students.first().id
                    errorMessage = null
                } else {
                    errorMessage = "කරුණාකර පළමුව හැඳුනුම්පත් අංකය ඇතුළත් කර ඇඟිලි සලකුණ තබන්න."
                }
            }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("student_id_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(scrollState)
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFFEFF6FF)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Fingerprint,
                                contentDescription = null,
                                tint = SchoolPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "ඇඟිලි සලකුණින් හඳුනා ගැනීම",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = SlateDark
                            )
                            Text(
                                text = "Fingerprint / ID Scan",
                                fontSize = 11.sp,
                                color = SlateMuted
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = SlateMuted
                        )
                    }
                }

                // Interactive Fingerprint Touch Scanner
                Box(
                    modifier = Modifier
                        .size(88.dp)
                        .scale(if (isFingerprintScanning) pulseScale else 1f)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                colors = if (matchedStudent != null) listOf(SchoolAccentGreen, Color(0xFF10B981))
                                else listOf(SchoolPrimary, Color(0xFF2563EB))
                            )
                        )
                        .clickable { triggerFingerprintTouch() }
                        .testTag("dialog_fingerprint_touch_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Fingerprint,
                        contentDescription = "Touch to Scan",
                        tint = Color.White,
                        modifier = Modifier.size(50.dp)
                    )
                }

                Text(
                    text = if (isFingerprintScanning) "ඇඟිලි සලකුණ ස්කෑන් කරමින්..."
                    else if (matchedStudent != null) "✓ ඇඟිලි සලකුණ තහවුරු විය!"
                    else "ඇඟිලි සලකුණ හෝ හැඳුනුම්පත් අංකය ඇතුළත් කරන්න",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (matchedStudent != null) SchoolAccentGreen else SlateMuted,
                    textAlign = TextAlign.Center
                )

                // ID Input Field
                OutlinedTextField(
                    value = idInput,
                    onValueChange = {
                        idInput = it.uppercase()
                        errorMessage = null
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("student_id_input"),
                    placeholder = { Text("උදා: STU001 හෝ 1234") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Badge,
                            contentDescription = null,
                            tint = SchoolPrimary
                        )
                    },
                    trailingIcon = {
                        if (idInput.isNotEmpty()) {
                            IconButton(onClick = {
                                idInput = ""
                                errorMessage = null
                            }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Clear",
                                    tint = SlateMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    },
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Characters,
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(
                        onSearch = { performVerify() }
                    )
                )

                // Verify Button
                Button(
                    onClick = { performVerify() },
                    colors = ButtonDefaults.buttonColors(containerColor = SchoolPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("submit_student_id_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("පරීක්ෂා කරන්න (Verify)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                // Error Message if any
                if (errorMessage != null) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFFEF2F2),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFECACA)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ErrorOutline,
                                contentDescription = null,
                                tint = Color(0xFFDC2626),
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = errorMessage ?: "",
                                color = Color(0xFFDC2626),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                // DYNAMIC CONTENT:
                // Only display the information belonging to that specific student!
                if (matchedStudent != null) {
                    SingleStudentDetailCard(
                        student = matchedStudent,
                        onConfirmAttendance = {
                            onStudentSelected(matchedStudent.id)
                        }
                    )
                } else if (trimmedInput.isEmpty()) {
                    // Empty placeholder instruction: DO NOT display any other student information
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = Color(0xFFF8FAFC),
                        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Fingerprint,
                                contentDescription = null,
                                tint = Color(0xFF94A3B8),
                                modifier = Modifier.size(26.dp)
                            )
                            Text(
                                text = "ඇඟිලි සලකුණ ස්කෑන් කළ පසු අදාළ සිසුවාගේ තොරතුරු පමණක් මෙහි විවෘත වේ.",
                                fontSize = 12.sp,
                                color = SlateMuted,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SingleStudentDetailCard(
    student: StudentEntity,
    onConfirmAttendance: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("identified_student_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
        border = androidx.compose.foundation.BorderStroke(2.dp, SchoolAccentGreen),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header status badge with clear Fingerprint vector icon and clean text
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFECFDF5),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFA7F3D0))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Fingerprint,
                        contentDescription = "Fingerprint Indicator",
                        tint = SchoolAccentGreen,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = if (student.faceData.isNotBlank()) "5-Scan තහවුරු කළ ඇඟිලි සලකුණ" else "ඇඟිලි සලකුණෙන් හඳුනා ගන්නා ලදී",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = SchoolAccentGreen
                    )
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Verified",
                        tint = SchoolAccentGreen,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }

            // Student photo or avatar
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(if (student.gender == "female") GirlsPinkLight else BoysBlueLight)
                    .border(2.5.dp, SchoolAccentGreen, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (student.photo.isNotBlank()) {
                    AsyncImage(
                        model = student.photo,
                        contentDescription = student.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Text(
                        text = student.name.take(1),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (student.gender == "female") GirlsPink else BoysBlue
                    )
                }
            }

            // Student Name
            Text(
                text = student.name,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = SlateDark,
                textAlign = TextAlign.Center
            )

            // Info rows: Only this student's details
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                StudentInfoPill(label = "🆔 හැඳුනුම්පත් අංකය (ID)", value = student.id)
                StudentInfoPill(label = "🎓 ශ්‍රේණිය (Grade)", value = student.grade)
                StudentInfoPill(
                    label = "👤 ස්ත්‍රී / පුරුෂ භාවය",
                    value = if (student.gender == "female") "ගැහැණු (Female)" else "පිරිමි (Male)"
                )
                if (student.faceData.isNotBlank()) {
                    StudentBiometricStatusPill(isVerified = true)
                }
                if (student.whatsapp.isNotBlank()) {
                    StudentInfoPill(label = "💬 WhatsApp", value = student.whatsapp)
                }
            }

            // Confirm Attendance Button
            Button(
                onClick = onConfirmAttendance,
                colors = ButtonDefaults.buttonColors(containerColor = SchoolAccentGreen),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .testTag("confirm_student_attendance_button")
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "පැමිණීම සටහන් කරන්න (Confirm)",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun StudentBiometricStatusPill(
    isVerified: Boolean
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFFF0FDF4),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFA7F3D0)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFDCFCE7)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Fingerprint,
                    contentDescription = "Fingerprint",
                    tint = SchoolAccentGreen,
                    modifier = Modifier.size(22.dp)
                )
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = "ඇඟිලි සලකුණු තත්ත්වය (Biometric Status)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = SlateMuted
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = SchoolAccentGreen,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = if (isVerified) "5-පියවර තහවුරු කළ සලකුණ (100% Verified)" else "ලියාපදිංචි කළ ඇඟිලි සලකුණ (Verified)",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = SchoolAccentGreen
                    )
                }
            }
        }
    }
}

@Composable
private fun StudentInfoPill(
    label: String,
    value: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White, RoundedCornerShape(8.dp))
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 11.5.sp,
            color = SlateMuted,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1.1f, fill = false)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = value,
            fontSize = 12.sp,
            color = SlateDark,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.End,
            modifier = Modifier.weight(1f, fill = false)
        )
    }
}
