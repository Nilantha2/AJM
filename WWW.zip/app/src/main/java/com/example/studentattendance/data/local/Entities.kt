package com.example.studentattendance.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "students")
data class StudentEntity(
    @PrimaryKey val id: String, // e.g. STU001
    val name: String,
    val grade: String,
    val gender: String, // "male" or "female"
    val dob: String,
    val whatsapp: String = "",
    val photo: String = "",
    val faceData: String = "",
    val registeredDate: String = ""
)

@Entity(tableName = "attendance")
data class AttendanceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: String,
    val studentName: String,
    val studentPhoto: String,
    val grade: String,
    val gender: String,
    val time: String, // e.g. "07:15"
    val date: String, // e.g. "2026-09-12"
    val year: Int,
    val month: Int,
    val day: Int,
    val dayName: String,
    val isOnTime: Boolean,
    val timestamp: Long
)

@Entity(tableName = "settings")
data class SettingEntity(
    @PrimaryKey val key: String,
    val value: String
)
