package com.example.studentattendance.ui.screens

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.studentattendance.ui.theme.*
import com.example.studentattendance.ui.viewmodel.AttendanceViewModel
import com.example.studentattendance.ui.viewmodel.MainTab

@Composable
fun MainScreen(
    viewModel: AttendanceViewModel,
    modifier: Modifier = Modifier
) {
    val selectedTab by viewModel.selectedMainTab.collectAsStateWithLifecycle()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = BackgroundCanvas,
        bottomBar = {
            NavigationBar(
                containerColor = Color.White,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("main_bottom_nav")
            ) {
                NavigationBarItem(
                    selected = selectedTab == MainTab.SCAN,
                    onClick = { viewModel.selectMainTab(MainTab.SCAN) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Fingerprint,
                            contentDescription = "Scan Attendance",
                            modifier = Modifier.size(24.dp)
                        )
                    },
                    label = {
                        Text(
                            text = "පැමිණීම සටහන්",
                            fontWeight = if (selectedTab == MainTab.SCAN) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 12.sp
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = SchoolPrimary,
                        selectedTextColor = SchoolPrimary,
                        indicatorColor = Color(0xFFDBEAFE)
                    ),
                    modifier = Modifier.testTag("nav_tab_scan")
                )

                NavigationBarItem(
                    selected = selectedTab == MainTab.ADMIN,
                    onClick = { viewModel.selectMainTab(MainTab.ADMIN) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = "Admin Portal",
                            modifier = Modifier.size(24.dp)
                        )
                    },
                    label = {
                        Text(
                            text = "ගුරු පරිපාලක",
                            fontWeight = if (selectedTab == MainTab.ADMIN) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 12.sp
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = SchoolPrimary,
                        selectedTextColor = SchoolPrimary,
                        indicatorColor = Color(0xFFDBEAFE)
                    ),
                    modifier = Modifier.testTag("nav_tab_admin")
                )
            }
        }
    ) { innerPadding ->
        when (selectedTab) {
            MainTab.SCAN -> ScanScreen(
                viewModel = viewModel,
                modifier = Modifier.padding(innerPadding)
            )
            MainTab.ADMIN -> AdminScreen(
                viewModel = viewModel,
                modifier = Modifier.padding(innerPadding)
            )
        }
    }
}
