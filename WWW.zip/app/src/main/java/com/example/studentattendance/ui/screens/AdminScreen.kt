package com.example.studentattendance.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.HowToReg
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.studentattendance.R
import com.example.studentattendance.ui.theme.*
import com.example.studentattendance.ui.viewmodel.AdminTab
import com.example.studentattendance.ui.viewmodel.AttendanceViewModel
import com.example.studentattendance.ui.viewmodel.MainTab

@Composable
fun AdminScreen(
    viewModel: AttendanceViewModel,
    modifier: Modifier = Modifier
) {
    val isLoggedIn by viewModel.isAdminLoggedIn.collectAsStateWithLifecycle()

    if (!isLoggedIn) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(top = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AdminLoginScreen(viewModel = viewModel)
        }
    } else {
        AdminDashboard(viewModel = viewModel, modifier = modifier)
    }
}

@Composable
fun AdminDashboard(
    viewModel: AttendanceViewModel,
    modifier: Modifier = Modifier
) {
    val selectedTab by viewModel.selectedAdminTab.collectAsStateWithLifecycle()
    val allStudents by viewModel.allStudents.collectAsStateWithLifecycle()
    val todayAttendance by viewModel.todayAttendance.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var showLogoutDialog by remember { mutableStateOf(false) }

    val verticalScroll = rememberScrollState()
    val horizontalTabScroll = rememberScrollState()

    // Logout Confirmation Dialog
    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.ExitToApp,
                    contentDescription = null,
                    tint = Color(0xFFDC2626),
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "පරිපාලක පැනලයෙන් පිටවීම",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp
                )
            },
            text = {
                Text(
                    text = "ඔබට ගුරු පරිපාලක පැනලයෙන් (Admin Panel) පිටවී සාමාන්‍ය පැමිණීම් ලේඛන තිරයට යාමට අවශ්‍යද?",
                    fontSize = 13.sp,
                    color = SlateDark
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutDialog = false
                        viewModel.adminLogout()
                        viewModel.selectMainTab(MainTab.SCAN)
                        Toast.makeText(context, "පරිපාලක පැනලයෙන් සාර්ථකව පිටවිය!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("ඔව්, පිටවන්න", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showLogoutDialog = false },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("අවලංගු කරන්න")
                }
            }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(verticalScroll)
            .padding(16.dp)
            .testTag("admin_dashboard"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Admin Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = SchoolPrimary),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .border(1.5.dp, Color(0xFF93C5FD), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        AsyncImage(
                            model = ImageRequest.Builder(LocalContext.current)
                                .data(R.drawable.app_logo)
                                .crossfade(true)
                                .build(),
                            contentDescription = "School Logo",
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(2.dp)
                                .clip(CircleShape),
                            contentScale = ContentScale.Fit
                        )
                    }
                    Column {
                        Text(
                            text = "👨‍🏫 ගුරු පරිපාලක පැනලය",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            maxLines = 1
                        )
                        Text(
                            text = "සිසු සහ පැමිණීම් කළමනාකරණය",
                            color = Color(0xFFBFDBFE),
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                    }
                }

                Button(
                    onClick = { showLogoutDialog = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFDC2626),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 3.dp),
                    modifier = Modifier
                        .wrapContentWidth()
                        .testTag("admin_logout_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ExitToApp,
                            contentDescription = "Logout",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "පිටවීම",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }
        }

        // Summary row - Redesigned Modern Executive KPI Metrics
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AdminStatCard(
                title = "සිසු සංඛ්‍යාව",
                value = allStudents.size.toString(),
                subtitle = "ලියාපදිංචි",
                badgeText = "මුළු සිසුන්",
                icon = Icons.Default.Groups,
                themeColor = Color(0xFF2563EB),
                containerBg = Color(0xFFEFF6FF),
                modifier = Modifier
                    .weight(1f)
                    .testTag("stat_total_students")
            )
            AdminStatCard(
                title = "අද පැමිණීම",
                value = todayAttendance.size.toString(),
                subtitle = "පැමිණි",
                badgeText = "${if (allStudents.isNotEmpty()) (todayAttendance.size * 100 / allStudents.size) else 0}%",
                icon = Icons.Default.HowToReg,
                themeColor = Color(0xFF059669),
                containerBg = Color(0xFFECFDF5),
                modifier = Modifier
                    .weight(1f)
                    .testTag("stat_today_attendance")
            )
            AdminStatCard(
                title = "ඇඟිලි සලකුණු",
                value = allStudents.count { it.faceData.isNotBlank() }.toString(),
                subtitle = "තහවුරු කළ",
                badgeText = "${allStudents.count { it.faceData.isNotBlank() }}/${allStudents.size}",
                icon = Icons.Default.Fingerprint,
                themeColor = Color(0xFF7C3AED),
                containerBg = Color(0xFFF5F3FF),
                modifier = Modifier
                    .weight(1f)
                    .testTag("stat_biometric_registered")
            )
        }

        // Horizontal Scrollable Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(horizontalTabScroll),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AdminNavPill(
                title = "➕ නව ලියාපදිංචිය",
                selected = selectedTab == AdminTab.REGISTER,
                onClick = { viewModel.selectAdminTab(AdminTab.REGISTER) }
            )
            AdminNavPill(
                title = "📋 සිසුන් (${allStudents.size})",
                selected = selectedTab == AdminTab.STUDENTS,
                onClick = { viewModel.selectAdminTab(AdminTab.STUDENTS) }
            )
            AdminNavPill(
                title = "📊 පැමිණීම් වාර්තා",
                selected = selectedTab == AdminTab.ATTENDANCE,
                onClick = { viewModel.selectAdminTab(AdminTab.ATTENDANCE) }
            )
            AdminNavPill(
                title = "🎓 ශ්‍රේණි වාර්තා",
                selected = selectedTab == AdminTab.GRADE_REPORTS,
                onClick = { viewModel.selectAdminTab(AdminTab.GRADE_REPORTS) }
            )
            AdminNavPill(
                title = "👤 එක් සිසු වාර්තා",
                selected = selectedTab == AdminTab.INDIVIDUAL_REPORTS,
                onClick = { viewModel.selectAdminTab(AdminTab.INDIVIDUAL_REPORTS) }
            )
            AdminNavPill(
                title = "⚙️ සැකසුම්",
                selected = selectedTab == AdminTab.SETTINGS,
                onClick = { viewModel.selectAdminTab(AdminTab.SETTINGS) }
            )
        }

        // Content of Active Tab
        when (selectedTab) {
            AdminTab.REGISTER -> AdminRegisterSection(viewModel = viewModel)
            AdminTab.STUDENTS -> AdminStudentsSection(viewModel = viewModel)
            AdminTab.ATTENDANCE -> AdminAttendanceReportsSection(viewModel = viewModel)
            AdminTab.GRADE_REPORTS -> AdminGradeReportsSection(viewModel = viewModel)
            AdminTab.INDIVIDUAL_REPORTS -> AdminIndividualReportsSection(viewModel = viewModel)
            AdminTab.SETTINGS -> AdminSettingsSection(viewModel = viewModel)
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun AdminStatCard(
    title: String,
    value: String,
    subtitle: String,
    badgeText: String,
    icon: ImageVector,
    themeColor: Color,
    containerBg: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(containerBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = themeColor,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = containerBg
                ) {
                    Text(
                        text = badgeText,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = themeColor,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                        maxLines = 1
                    )
                }
            }

            Text(
                text = value,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = SlateDark,
                lineHeight = 24.sp
            )

            Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text(
                    text = title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = SlateDark,
                    maxLines = 1,
                    softWrap = false
                )
                Text(
                    text = subtitle,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Medium,
                    color = SlateMuted,
                    maxLines = 1,
                    softWrap = false
                )
            }
        }
    }
}

@Composable
fun AdminNavPill(
    title: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = if (selected) SchoolPrimary else Color.White,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (selected) SchoolPrimary else Color(0xFFCBD5E1)
        ),
        shadowElevation = if (selected) 2.dp else 0.dp
    ) {
        Text(
            text = title,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.SemiBold,
            fontSize = 12.sp,
            color = if (selected) Color.White else SlateDark,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            maxLines = 1,
            softWrap = false
        )
    }
}
