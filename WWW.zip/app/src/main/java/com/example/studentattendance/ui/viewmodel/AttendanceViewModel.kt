package com.example.studentattendance.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.studentattendance.data.local.AppDatabase
import com.example.studentattendance.data.local.AttendanceEntity
import com.example.studentattendance.data.local.StudentEntity
import com.example.studentattendance.data.repository.AttendanceRepository
import com.example.studentattendance.data.repository.MarkAttendanceResult
import com.example.studentattendance.data.repository.SchoolSettings
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

enum class MainTab { SCAN, ADMIN }

enum class AdminTab {
    REGISTER,
    STUDENTS,
    ATTENDANCE,
    GRADE_REPORTS,
    INDIVIDUAL_REPORTS,
    SETTINGS
}

enum class ReportViewMode { DAILY, MONTHLY, YEARLY }

data class LiveStats(
    val onTimeBoys: Int = 0,
    val onTimeGirls: Int = 0,
    val lateBoys: Int = 0,
    val lateGirls: Int = 0
)

class AttendanceViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    val repository = AttendanceRepository(database)

    // Current real-time clock
    private val _currentTime = MutableStateFlow(getCurrentTimeFormatted())
    val currentTime: StateFlow<String> = _currentTime.asStateFlow()

    private val _todayDateString = MutableStateFlow(getTodaySinhalaDate())
    val todayDateString: StateFlow<String> = _todayDateString.asStateFlow()

    val todayRawDate: String = AttendanceRepository.getTodayDateString()

    // Navigation & View state
    private val _selectedMainTab = MutableStateFlow(MainTab.SCAN)
    val selectedMainTab: StateFlow<MainTab> = _selectedMainTab.asStateFlow()

    private val _selectedAdminTab = MutableStateFlow(AdminTab.REGISTER)
    val selectedAdminTab: StateFlow<AdminTab> = _selectedAdminTab.asStateFlow()

    // Settings
    private val _settings = MutableStateFlow(SchoolSettings())
    val settings: StateFlow<SchoolSettings> = _settings.asStateFlow()

    // Students & Attendance
    val allStudents: StateFlow<List<StudentEntity>> = repository.allStudents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val todayAttendance: StateFlow<List<AttendanceEntity>> = repository.getAttendanceForDate(todayRawDate)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val liveStats: StateFlow<LiveStats> = todayAttendance.map { list ->
        var otBoys = 0
        var otGirls = 0
        var lBoys = 0
        var lGirls = 0
        list.forEach { record ->
            val isMale = record.gender.equals("male", ignoreCase = true)
            if (record.isOnTime) {
                if (isMale) otBoys++ else otGirls++
            } else {
                if (isMale) lBoys++ else lGirls++
            }
        }
        LiveStats(otBoys, otGirls, lBoys, lGirls)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), LiveStats())

    val topArrivals: StateFlow<List<AttendanceEntity>> = todayAttendance.map { list ->
        list.sortedBy { it.timestamp }.take(3)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Scanner UI state
    private val _isIdModalOpen = MutableStateFlow(false)
    val isIdModalOpen: StateFlow<Boolean> = _isIdModalOpen.asStateFlow()

    private val _scannerStatusText = MutableStateFlow("ස්කෑන් කිරීමට සූදානම්")
    val scannerStatusText: StateFlow<String> = _scannerStatusText.asStateFlow()

    private val _isScanningAnimation = MutableStateFlow(false)
    val isScanningAnimation: StateFlow<Boolean> = _isScanningAnimation.asStateFlow()

    private val _lastScannedStudent = MutableStateFlow<StudentEntity?>(null)
    val lastScannedStudent: StateFlow<StudentEntity?> = _lastScannedStudent.asStateFlow()

    private val _lastScannedRecord = MutableStateFlow<AttendanceEntity?>(null)
    val lastScannedRecord: StateFlow<AttendanceEntity?> = _lastScannedRecord.asStateFlow()

    // Admin UI state
    private val _isAdminLoggedIn = MutableStateFlow(false)
    val isAdminLoggedIn: StateFlow<Boolean> = _isAdminLoggedIn.asStateFlow()

    private val _adminPasswordInput = MutableStateFlow("")
    val adminPasswordInput: StateFlow<String> = _adminPasswordInput.asStateFlow()

    private val _adminPasswordVisible = MutableStateFlow(false)
    val adminPasswordVisible: StateFlow<Boolean> = _adminPasswordVisible.asStateFlow()

    private val _adminLoginError = MutableStateFlow<String?>(null)
    val adminLoginError: StateFlow<String?> = _adminLoginError.asStateFlow()

    // Admin Sections
    private val _studentSearchQuery = MutableStateFlow("")
    val studentSearchQuery: StateFlow<String> = _studentSearchQuery.asStateFlow()

    val filteredStudents: StateFlow<List<StudentEntity>> = combine(allStudents, _studentSearchQuery) { list, query ->
        if (query.isBlank()) list
        else list.filter {
            it.name.contains(query, ignoreCase = true) || it.id.contains(query, ignoreCase = true)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _editingStudent = MutableStateFlow<StudentEntity?>(null)
    val editingStudent: StateFlow<StudentEntity?> = _editingStudent.asStateFlow()

    // Attendance Reports section
    private val _reportViewMode = MutableStateFlow(ReportViewMode.DAILY)
    val reportViewMode: StateFlow<ReportViewMode> = _reportViewMode.asStateFlow()

    private val _selectedDailyDate = MutableStateFlow(todayRawDate)
    val selectedDailyDate: StateFlow<String> = _selectedDailyDate.asStateFlow()

    private val _selectedMonthlyDate = MutableStateFlow(todayRawDate.substring(0, 7)) // YYYY-MM
    val selectedMonthlyDate: StateFlow<String> = _selectedMonthlyDate.asStateFlow()

    private val _selectedYearlyDate = MutableStateFlow(Calendar.getInstance().get(Calendar.YEAR))
    val selectedYearlyDate: StateFlow<Int> = _selectedYearlyDate.asStateFlow()

    // Grade Reports section
    private val _selectedGrade = MutableStateFlow("10 ශ්‍රේණිය")
    val selectedGrade: StateFlow<String> = _selectedGrade.asStateFlow()

    private val _selectedGradeDate = MutableStateFlow(todayRawDate)
    val selectedGradeDate: StateFlow<String> = _selectedGradeDate.asStateFlow()

    // Individual Student Report section
    private val _individualStudentId = MutableStateFlow("")
    val individualStudentId: StateFlow<String> = _individualStudentId.asStateFlow()

    private val _individualReportType = MutableStateFlow("daily")
    val individualReportType: StateFlow<String> = _individualReportType.asStateFlow()

    private val _individualRemarks = MutableStateFlow("")
    val individualRemarks: StateFlow<String> = _individualRemarks.asStateFlow()

    init {
        viewModelScope.launch {
            repository.initializeDefaultDataIfEmpty()
            _settings.value = repository.getSettings()
        }

        // Ticking Clock Coroutine
        viewModelScope.launch {
            while (true) {
                _currentTime.value = getCurrentTimeFormatted()
                delay(1000)
            }
        }
    }

    fun selectMainTab(tab: MainTab) {
        _selectedMainTab.value = tab
    }

    fun selectAdminTab(tab: AdminTab) {
        _selectedAdminTab.value = tab
    }

    // Scanner actions
    fun openIdModal() {
        _isIdModalOpen.value = true
    }

    fun closeIdModal() {
        _isIdModalOpen.value = false
    }

    fun scanStudent(studentId: String) {
        viewModelScope.launch {
            closeIdModal()
            _isScanningAnimation.value = true
            _scannerStatusText.value = "ස්කෑන් කරමින්..."
            delay(1500)
            _isScanningAnimation.value = false

            when (val result = repository.markAttendance(studentId)) {
                is MarkAttendanceResult.Success -> {
                    _lastScannedStudent.value = result.student
                    _lastScannedRecord.value = result.attendance
                    _scannerStatusText.value = "✓ හඳුනාගැනීම සාර්ථකයි!"
                    Toast.makeText(getApplication(), "✅ ${result.student.name} පැමිණීම සටහන් විය!", Toast.LENGTH_SHORT).show()
                }
                is MarkAttendanceResult.AlreadyMarked -> {
                    _lastScannedStudent.value = result.student
                    val existing = repository.getAttendanceForDate(todayRawDate).firstOrNull()?.find { it.studentId == result.student.id }
                    _lastScannedRecord.value = existing
                    _scannerStatusText.value = "⚠️ දැනටමත් සටහන් කර ඇත!"
                    Toast.makeText(getApplication(), "⚠️ දැනටමත් අද සටහන් කර ඇත!", Toast.LENGTH_SHORT).show()
                }
                is MarkAttendanceResult.StudentNotFound -> {
                    _scannerStatusText.value = "❌ ශිෂ්‍යයා සොයාගත නොහැක!"
                    Toast.makeText(getApplication(), "❌ $studentId අංකය සොයාගත නොහැක!", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun resetScan() {
        _lastScannedStudent.value = null
        _lastScannedRecord.value = null
        _scannerStatusText.value = "ස්කෑන් කිරීමට සූදානම්"
    }

    // Admin Login
    fun setAdminPasswordInput(password: String) {
        _adminPasswordInput.value = password
        _adminLoginError.value = null
    }

    fun togglePasswordVisibility() {
        _adminPasswordVisible.value = !_adminPasswordVisible.value
    }

    fun adminLogin() {
        val expected = _settings.value.adminPassword
        if (_adminPasswordInput.value == expected) {
            _isAdminLoggedIn.value = true
            _adminLoginError.value = null
            _adminPasswordInput.value = ""
        } else {
            _adminLoginError.value = "❌ වැරදි මුරපදයක්! නැවත උත්සාහ කරන්න."
        }
    }

    fun adminLogout() {
        _isAdminLoggedIn.value = false
        _adminPasswordInput.value = ""
        _adminLoginError.value = null
    }

    // Student CRUD
    fun setStudentSearchQuery(q: String) {
        _studentSearchQuery.value = q
    }

    fun registerStudent(student: StudentEntity, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.insertStudent(student)
            Toast.makeText(getApplication(), "✅ සිසුවා සාර්ථකව ලියාපදිංචි විය!", Toast.LENGTH_SHORT).show()
            onSuccess()
        }
    }

    fun startEditingStudent(student: StudentEntity) {
        _editingStudent.value = student
    }

    fun cancelEditingStudent() {
        _editingStudent.value = null
    }

    fun saveEditedStudent(student: StudentEntity) {
        viewModelScope.launch {
            repository.updateStudent(student)
            _editingStudent.value = null
            Toast.makeText(getApplication(), "✅ සිසු විස්තර යාවත්කාලීන කරන ලදී!", Toast.LENGTH_SHORT).show()
        }
    }

    fun deleteStudent(studentId: String) {
        viewModelScope.launch {
            repository.deleteStudent(studentId)
            Toast.makeText(getApplication(), "🗑️ සිසුවා ඉවත් කරන ලදී!", Toast.LENGTH_SHORT).show()
        }
    }

    // Reports filters
    fun setReportViewMode(mode: ReportViewMode) {
        _reportViewMode.value = mode
    }

    fun setSelectedDailyDate(date: String) {
        _selectedDailyDate.value = date
    }

    fun setSelectedMonthlyDate(monthStr: String) {
        _selectedMonthlyDate.value = monthStr
    }

    fun setSelectedYearlyDate(year: Int) {
        _selectedYearlyDate.value = year
    }

    fun setSelectedGrade(grade: String) {
        _selectedGrade.value = grade
    }

    fun setSelectedGradeDate(date: String) {
        _selectedGradeDate.value = date
    }

    fun setIndividualStudentId(id: String) {
        _individualStudentId.value = id
    }

    fun setIndividualReportType(type: String) {
        _individualReportType.value = type
    }

    fun setIndividualRemarks(remarks: String) {
        _individualRemarks.value = remarks
    }

    // Settings actions
    fun saveSettings(newSettings: SchoolSettings) {
        viewModelScope.launch {
            repository.saveSettings(newSettings)
            _settings.value = newSettings
            Toast.makeText(getApplication(), "✅ සැකසුම් සුරකින ලදී!", Toast.LENGTH_SHORT).show()
        }
    }

    fun generateSampleData() {
        viewModelScope.launch {
            repository.generateSampleAttendanceData()
            Toast.makeText(getApplication(), "✅ ටෙස්ට් දත්ත සාර්ථකව ඇතුළත් විය!", Toast.LENGTH_SHORT).show()
        }
    }

    fun clearAllAttendance() {
        viewModelScope.launch {
            repository.clearAttendance()
            resetScan()
            Toast.makeText(getApplication(), "🗑️ සියලු පැමිණීම් දත්ත මකා දමන ලදී!", Toast.LENGTH_SHORT).show()
        }
    }

    // WhatsApp Sharing for parent
    fun shareIndividualReportViaWhatsApp(context: Context) {
        val student = allStudents.value.find { it.id == _individualStudentId.value }
        if (student == null) {
            Toast.makeText(context, "⚠️ කරුණාකර සිසුවෙකු තෝරන්න!", Toast.LENGTH_SHORT).show()
            return
        }
        if (student.whatsapp.isBlank() || student.whatsapp == "නැත") {
            Toast.makeText(context, "⚠️ WhatsApp අංකයක් ඇතුළත් කර නැත!", Toast.LENGTH_LONG).show()
            return
        }

        val school = _settings.value.schoolName
        val greeting = _settings.value.parentGreeting
        val remarks = _individualRemarks.value
        val reportType = when (_individualReportType.value) {
            "daily" -> "දෛනික"
            "monthly" -> "මාසික"
            else -> "වාර්ෂික"
        }

        val message = StringBuilder().apply {
            append("$greeting ගරු දෙමාපියනි,\n\n")
            append("මෙය *$school* වෙතින්.\n\n")
            append("ඔබගේ දරුවා *${student.name}* (${student.grade}) ගේ *$reportType පැමිණීම් වාර්තාව*:\n")
            append("🆔 ශිෂ්‍ය අංකය: ${student.id}\n")
            append("📅 දිනය: $todayRawDate\n\n")
            if (remarks.isNotBlank()) {
                append("👨‍🏫 *ගුරුවරයාගේ පණිවිඩය:*\n$remarks\n\n")
            }
            append("ස්තූතියි,\n*$school* 🏫")
        }.toString()

        var phone = student.whatsapp.filter { it.isDigit() }
        if (phone.startsWith("0")) {
            phone = "94" + phone.substring(1)
        } else if (!phone.startsWith("94")) {
            phone = "94$phone"
        }

        try {
            val url = "https://wa.me/$phone?text=" + Uri.encode(message)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse(url)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // Fallback generic share
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, message)
            }
            context.startActivity(Intent.createChooser(shareIntent, "වාර්තාව බෙදාගන්න"))
        }
    }

    companion object {
        fun getCurrentTimeFormatted(): String {
            val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
            return sdf.format(Date())
        }

        fun getTodaySinhalaDate(): String {
            val cal = Calendar.getInstance()
            val year = cal.get(Calendar.YEAR)
            val month = cal.get(Calendar.MONTH) + 1
            val day = cal.get(Calendar.DAY_OF_MONTH)
            val dayName = AttendanceRepository.getSinhalaDayName(cal.get(Calendar.DAY_OF_WEEK))

            val monthName = when (month) {
                1 -> "ජනවාරි"
                2 -> "පෙබරවාරි"
                3 -> "මාර්තු"
                4 -> "අප්‍රේල්"
                5 -> "මැයි"
                6 -> "ජූනි"
                7 -> "ජූලි"
                8 -> "අගෝස්තු"
                9 -> "සැප්තැම්බර්"
                10 -> "ඔක්තෝබර්"
                11 -> "නොවැම්බර්"
                12 -> "දෙසැම්බර්"
                else -> ""
            }
            return "$year $monthName $day, $dayName"
        }
    }
}
