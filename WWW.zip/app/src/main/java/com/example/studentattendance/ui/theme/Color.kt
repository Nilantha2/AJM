package com.example.studentattendance.ui.theme

import androidx.compose.ui.graphics.Color

val SchoolPrimary = Color(0xFF1E3A8A)
val SchoolPrimaryLight = Color(0xFF3B82F6)
val SchoolPrimaryDark = Color(0xFF0F172A)
val SchoolAccentGreen = Color(0xFF10B981)
val SchoolAccentGreenDark = Color(0xFF059669)

val BoysBlue = Color(0xFF2563EB)
val BoysBlueLight = Color(0xFFEFF6FF)
val BoysBlueBorder = Color(0xFF60A5FA)

val GirlsPink = Color(0xFFEC4899)
val GirlsPinkLight = Color(0xFFFDF2F8)
val GirlsPinkBorder = Color(0xFFF472B6)

val LateOrange = Color(0xFFEA580C)
val LateOrangeLight = Color(0xFFFFF7ED)
val LateOrangeBorder = Color(0xFFFB923C)

val LateRed = Color(0xFFDC2626)
val LateRedLight = Color(0xFFFEF2F2)
val LateRedBorder = Color(0xFFFCA5A5)

val GoldMedal = Color(0xFFF59E0B)
val SilverMedal = Color(0xFF94A3B8)
val BronzeMedal = Color(0xFFD97706)

val SurfaceCard = Color(0xFFFFFFFF)
val BackgroundCanvas = Color(0xFFF8FAFC)
val SlateDark = Color(0xFF1E293B)
val SlateMuted = Color(0xFF64748B)
val SlateBorder = Color(0xFFE2E8F0)
