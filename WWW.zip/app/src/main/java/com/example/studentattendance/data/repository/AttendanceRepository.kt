package com.example.studentattendance.data.repository

import com.example.studentattendance.data.local.AppDatabase
import com.example.studentattendance.data.local.AttendanceEntity
import com.example.studentattendance.data.local.SettingEntity
import com.example.studentattendance.data.local.StudentEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class SchoolSettings(
    val schoolName: String = "බ/ Uav-paranagama විද්‍යාලය",
    val schoolAddress: String = "Uav-paranagama",
    val schoolPhone: String = "055-1234567",
    val schoolEmail: String = "https://sinhalas2.blogspot.com/",
    val schoolLogoUrl: String = "https://i.imgur.com/ZcvAfkf.png",
    val morningStartTime: String = "06:30",
    val attendanceCutoffTime: String = "07:30",
    val lateCutoffTime: String = "08:00",
    val schoolEndTime: String = "13:30",
    val reportLanguage: String = "si",
    val reportFooter: String = "අධ්‍යාපනය ජාතියේ",
    val parentGreeting: String = "ආයුබෝවන්",
    val parentMessageTemplate: String = "ගරු දෙමාපියනි,\n\nඔබගේ දරුවා අද පාසලට {time} ට පැමිණ ඇත.\nතත්වය: {status}\n\nස්තූතියි,\n{school_name}",
    val adminPassword: String = "Nilantha",
    val emergencyContact: String = "077-1234567",
    val showGoodBehavior: Boolean = true,
    val showBadBehavior: Boolean = true,
    val goodBehavior1: String = "නියමිත වේලාවට පැමිණීම",
    val goodBehavior2: String = "හොඳ පෙනුමක්",
    val goodBehavior3: String = "ආචාරශීලී හැසිරීම",
    val badBehavior1: String = "ප්‍රමාද වීම",
    val badBehavior2: String = "නොපැමිණීම",
    val badBehavior3: String = "නුසුදුසු හැසිරීම"
)

sealed class MarkAttendanceResult {
    data class Success(val attendance: AttendanceEntity, val student: StudentEntity) : MarkAttendanceResult()
    data class AlreadyMarked(val student: StudentEntity) : MarkAttendanceResult()
    object StudentNotFound : MarkAttendanceResult()
}

class AttendanceRepository(private val database: AppDatabase) {
    private val studentDao = database.studentDao()
    private val attendanceDao = database.attendanceDao()
    private val settingDao = database.settingDao()

    val allStudents: Flow<List<StudentEntity>> = studentDao.getAllStudents()
    val allSettings: Flow<List<SettingEntity>> = settingDao.getAllSettings()

    fun getAttendanceForDate(date: String): Flow<List<AttendanceEntity>> =
        attendanceDao.getAttendanceForDate(date)

    fun getAttendanceForMonth(year: Int, month: Int): Flow<List<AttendanceEntity>> =
        attendanceDao.getAttendanceForMonth(year, month)

    fun getAttendanceForYear(year: Int): Flow<List<AttendanceEntity>> =
        attendanceDao.getAttendanceForYear(year)

    fun getAttendanceForStudent(studentId: String): Flow<List<AttendanceEntity>> =
        attendanceDao.getAttendanceForStudent(studentId)

    suspend fun initializeDefaultDataIfEmpty() {
        val existingStudents = studentDao.getAllStudents().firstOrNull() ?: emptyList()
        if (existingStudents.isEmpty()) {
            val defaults = listOf(
                StudentEntity(
                    id = "STU001",
                    name = "සදරුවන් පෙරේරා",
                    grade = "10 ශ්‍රේණිය",
                    gender = "male",
                    dob = "2010-05-15",
                    whatsapp = "0771234567",
                    photo = "",
                    faceData = "fp_5x_verified_stu001",
                    registeredDate = getTodayDateString()
                ),
                StudentEntity(
                    id = "STU002",
                    name = "නිමේෂා සිල්වා",
                    grade = "9 ශ්‍රේණිය",
                    gender = "female",
                    dob = "2011-08-22",
                    whatsapp = "0772345678",
                    photo = "",
                    faceData = "fp_5x_verified_stu002",
                    registeredDate = getTodayDateString()
                ),
                StudentEntity(
                    id = "STU003",
                    name = "කවිංද ජයවර්ධන",
                    grade = "11 ශ්‍රේණිය",
                    gender = "male",
                    dob = "2009-12-10",
                    whatsapp = "0773456789",
                    photo = "",
                    faceData = "fp_5x_verified_stu003",
                    registeredDate = getTodayDateString()
                )
            )
            studentDao.insertStudents(defaults)
        }
    }

    suspend fun getSettings(): SchoolSettings {
        val list = settingDao.getAllSettings().firstOrNull() ?: emptyList()
        val map = list.associate { it.key to it.value }

        return SchoolSettings(
            schoolName = map["schoolName"] ?: "බ/ Uva-paranagama විද්‍යාලය",
            schoolAddress = map["schoolAddress"] ?: "Uva-paranagama",
            schoolPhone = map["schoolPhone"] ?: "055-1234567",
            schoolEmail = map["schoolEmail"] ?: "https://sinhalas2.blogspot.com/",
            schoolLogoUrl = map["schoolLogoUrl"]?.takeIf { it.isNotBlank() } ?: "https://i.imgur.com/ZcvAfkf.png",
            morningStartTime = map["morningStartTime"] ?: "06:30",
            attendanceCutoffTime = map["attendanceCutoffTime"] ?: "07:30",
            lateCutoffTime = map["lateCutoffTime"] ?: "08:00",
            schoolEndTime = map["schoolEndTime"] ?: "13:30",
            reportLanguage = map["reportLanguage"] ?: "si",
            reportFooter = map["reportFooter"] ?: "අධ්‍යාපනය ජාතියේ ",
            parentGreeting = map["parentGreeting"] ?: "ආයුබෝවන්",
            parentMessageTemplate = map["parentMessageTemplate"] ?: "ගරු දෙමාපියනි,\n\nඔබගේ දරුවා අද පාසලට {time} ට පැමිණ ඇත.\nතත්වය: {status}\n\nස්තූතියි,\n{school_name}",
            adminPassword = map["adminPassword"] ?: "Nilantha",
            emergencyContact = map["emergencyContact"] ?: "077-1234567",
            showGoodBehavior = map["showGoodBehavior"]?.toBooleanStrictOrNull() ?: true,
            showBadBehavior = map["showBadBehavior"]?.toBooleanStrictOrNull() ?: true,
            goodBehavior1 = map["goodBehavior1"] ?: "නියමිත වේලාවට පැමිණීම",
            goodBehavior2 = map["goodBehavior2"] ?: "හොඳ පෙනුමක්",
            goodBehavior3 = map["goodBehavior3"] ?: "ආචාරශීලී හැසිරීම",
            badBehavior1 = map["badBehavior1"] ?: "ප්‍රමාද වීම",
            badBehavior2 = map["badBehavior2"] ?: "නොපැමිණීම",
            badBehavior3 = map["badBehavior3"] ?: "නුසුදුසු හැසිරීම"
        )
    }

    suspend fun saveSettings(settings: SchoolSettings) {
        val list = listOf(
            SettingEntity("schoolName", settings.schoolName),
            SettingEntity("schoolAddress", settings.schoolAddress),
            SettingEntity("schoolPhone", settings.schoolPhone),
            SettingEntity("schoolEmail", settings.schoolEmail),
            SettingEntity("schoolLogoUrl", settings.schoolLogoUrl),
            SettingEntity("morningStartTime", settings.morningStartTime),
            SettingEntity("attendanceCutoffTime", settings.attendanceCutoffTime),
            SettingEntity("lateCutoffTime", settings.lateCutoffTime),
            SettingEntity("schoolEndTime", settings.schoolEndTime),
            SettingEntity("reportLanguage", settings.reportLanguage),
            SettingEntity("reportFooter", settings.reportFooter),
            SettingEntity("parentGreeting", settings.parentGreeting),
            SettingEntity("parentMessageTemplate", settings.parentMessageTemplate),
            SettingEntity("adminPassword", settings.adminPassword),
            SettingEntity("emergencyContact", settings.emergencyContact),
            SettingEntity("showGoodBehavior", settings.showGoodBehavior.toString()),
            SettingEntity("showBadBehavior", settings.showBadBehavior.toString()),
            SettingEntity("goodBehavior1", settings.goodBehavior1),
            SettingEntity("goodBehavior2", settings.goodBehavior2),
            SettingEntity("goodBehavior3", settings.goodBehavior3),
            SettingEntity("badBehavior1", settings.badBehavior1),
            SettingEntity("badBehavior2", settings.badBehavior2),
            SettingEntity("badBehavior3", settings.badBehavior3)
        )
        settingDao.setSettings(list)
    }

    suspend fun markAttendance(studentId: String, customTime: String? = null): MarkAttendanceResult {
        val student = studentDao.getStudentById(studentId.trim().uppercase())
            ?: return MarkAttendanceResult.StudentNotFound

        val today = getTodayDateString()
        val existing = attendanceDao.getRecord(student.id, today)
        if (existing != null) {
            return MarkAttendanceResult.AlreadyMarked(student)
        }

        val settings = getSettings()
        val now = Calendar.getInstance()
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        val timeString = customTime ?: timeFormat.format(now.time)

        // Check cutoff
        val cutoffParts = settings.attendanceCutoffTime.split(":")
        val cutoffHour = cutoffParts.getOrNull(0)?.toIntOrNull() ?: 7
        val cutoffMin = cutoffParts.getOrNull(1)?.toIntOrNull() ?: 30

        val timeParts = timeString.split(":")
        val curHour = timeParts.getOrNull(0)?.toIntOrNull() ?: now.get(Calendar.HOUR_OF_DAY)
        val curMin = timeParts.getOrNull(1)?.toIntOrNull() ?: now.get(Calendar.MINUTE)

        val isOnTime = (curHour < cutoffHour) || (curHour == cutoffHour && curMin < cutoffMin)

        val dayName = getSinhalaDayName(now.get(Calendar.DAY_OF_WEEK))

        val record = AttendanceEntity(
            studentId = student.id,
            studentName = student.name,
            studentPhoto = student.photo,
            grade = student.grade,
            gender = student.gender,
            time = timeString,
            date = today,
            year = now.get(Calendar.YEAR),
            month = now.get(Calendar.MONTH) + 1,
            day = now.get(Calendar.DAY_OF_MONTH),
            dayName = dayName,
            isOnTime = isOnTime,
            timestamp = System.currentTimeMillis()
        )

        attendanceDao.insertAttendance(record)
        return MarkAttendanceResult.Success(record, student)
    }

    suspend fun insertStudent(student: StudentEntity) {
        studentDao.insertStudent(student)
    }

    suspend fun updateStudent(student: StudentEntity) {
        studentDao.updateStudent(student)
    }

    suspend fun deleteStudent(studentId: String) {
        studentDao.deleteStudentById(studentId)
    }

    suspend fun clearAttendance() {
        attendanceDao.clearAll()
    }

    suspend fun generateSampleAttendanceData() {
        initializeDefaultDataIfEmpty()
        val students = studentDao.getAllStudents().firstOrNull() ?: emptyList()
        if (students.isEmpty()) return

        val today = getTodayDateString()
        val now = Calendar.getInstance()
        val dayName = getSinhalaDayName(now.get(Calendar.DAY_OF_WEEK))

        val samples = listOf(
            AttendanceEntity(
                studentId = students[0].id,
                studentName = students[0].name,
                studentPhoto = students[0].photo,
                grade = students[0].grade,
                gender = students[0].gender,
                time = "07:10",
                date = today,
                year = now.get(Calendar.YEAR),
                month = now.get(Calendar.MONTH) + 1,
                day = now.get(Calendar.DAY_OF_MONTH),
                dayName = dayName,
                isOnTime = true,
                timestamp = System.currentTimeMillis() - 1000 * 60 * 30
            ),
            AttendanceEntity(
                studentId = if (students.size > 1) students[1].id else "STU002",
                studentName = if (students.size > 1) students[1].name else "නිමේෂා සිල්වා",
                studentPhoto = if (students.size > 1) students[1].photo else "",
                grade = if (students.size > 1) students[1].grade else "9 ශ්‍රේණිය",
                gender = "female",
                time = "07:18",
                date = today,
                year = now.get(Calendar.YEAR),
                month = now.get(Calendar.MONTH) + 1,
                day = now.get(Calendar.DAY_OF_MONTH),
                dayName = dayName,
                isOnTime = true,
                timestamp = System.currentTimeMillis() - 1000 * 60 * 20
            ),
            AttendanceEntity(
                studentId = if (students.size > 2) students[2].id else "STU003",
                studentName = if (students.size > 2) students[2].name else "කවිංද ජයවර්ධන",
                studentPhoto = if (students.size > 2) students[2].photo else "",
                grade = if (students.size > 2) students[2].grade else "11 ශ්‍රේණිය",
                gender = "male",
                time = "07:38",
                date = today,
                year = now.get(Calendar.YEAR),
                month = now.get(Calendar.MONTH) + 1,
                day = now.get(Calendar.DAY_OF_MONTH),
                dayName = dayName,
                isOnTime = false,
                timestamp = System.currentTimeMillis() - 1000 * 60 * 5
            )
        )
        attendanceDao.insertAttendanceList(samples)
    }

    companion object {
        fun getTodayDateString(): String {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            return sdf.format(Date())
        }

        fun getSinhalaDayName(dayOfWeek: Int): String {
            return when (dayOfWeek) {
                Calendar.SUNDAY -> "ඉරිදා"
                Calendar.MONDAY -> "සඳුදා"
                Calendar.TUESDAY -> "අඟහරුවාදා"
                Calendar.WEDNESDAY -> "බදාදා"
                Calendar.THURSDAY -> "බ්‍රහස්පතින්දා"
                Calendar.FRIDAY -> "සිකුරාදා"
                Calendar.SATURDAY -> "සෙනසුරාදා"
                else -> ""
            }
        }
    }
}
