package com.example.studentattendance.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.studentattendance.ui.components.*
import com.example.studentattendance.ui.viewmodel.AttendanceViewModel

@Composable
fun ScanScreen(
    viewModel: AttendanceViewModel,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val todayDate by viewModel.todayDateString.collectAsStateWithLifecycle()
    val currentTime by viewModel.currentTime.collectAsStateWithLifecycle()
    val liveStats by viewModel.liveStats.collectAsStateWithLifecycle()
    val topArrivals by viewModel.topArrivals.collectAsStateWithLifecycle()
    val allStudents by viewModel.allStudents.collectAsStateWithLifecycle()

    val isIdModalOpen by viewModel.isIdModalOpen.collectAsStateWithLifecycle()
    val isScanningAnimation by viewModel.isScanningAnimation.collectAsStateWithLifecycle()
    val scannerStatusText by viewModel.scannerStatusText.collectAsStateWithLifecycle()
    val lastScannedStudent by viewModel.lastScannedStudent.collectAsStateWithLifecycle()
    val lastScannedRecord by viewModel.lastScannedRecord.collectAsStateWithLifecycle()

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .testTag("scan_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        AppHeader(
            schoolName = settings.schoolName,
            todayDate = todayDate,
            morningStartTime = settings.morningStartTime,
            attendanceCutoffTime = settings.attendanceCutoffTime,
            schoolLogoUrl = settings.schoolLogoUrl
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            LiveStatsDashboard(
                onTimeBoys = liveStats.onTimeBoys,
                onTimeGirls = liveStats.onTimeGirls,
                lateBoys = liveStats.lateBoys,
                lateGirls = liveStats.lateGirls,
                currentTime = currentTime,
                morningStartTime = settings.morningStartTime,
                cutoffTime = settings.attendanceCutoffTime
            )

            SchoolTimetableCard(
                morningStartTime = settings.morningStartTime,
                cutoffTime = settings.attendanceCutoffTime,
                lateCutoffTime = settings.lateCutoffTime,
                schoolEndTime = settings.schoolEndTime,
                currentTime = currentTime
            )

            TopArrivalsPodium(
                top3Arrivals = topArrivals
            )

            if (lastScannedStudent != null) {
                ScannedStudentDetailCard(
                    student = lastScannedStudent!!,
                    record = lastScannedRecord,
                    onNewScanClick = { viewModel.resetScan() }
                )
            } else {
                FingerprintScannerBox(
                    isScanning = isScanningAnimation,
                    statusText = scannerStatusText,
                    onScanClick = { viewModel.openIdModal() }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (isIdModalOpen) {
        StudentIdDialog(
            students = allStudents,
            onDismiss = { viewModel.closeIdModal() },
            onStudentSelected = { studentId ->
                viewModel.scanStudent(studentId)
            }
        )
    }
}
