package com.example.studentattendance.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.studentattendance.R
import com.example.studentattendance.data.local.AttendanceEntity
import com.example.studentattendance.data.local.StudentEntity
import com.example.studentattendance.data.repository.AttendanceRepository
import com.example.studentattendance.ui.components.DetailRow
import com.example.studentattendance.ui.theme.*
import com.example.studentattendance.ui.viewmodel.AttendanceViewModel
import com.example.studentattendance.ui.viewmodel.ReportViewMode
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

fun saveBitmapToInternalStorage(context: Context, bitmap: Bitmap): String {
    return try {
        val dir = File(context.filesDir, "student_photos").apply { if (!exists()) mkdirs() }
        val file = File(dir, "student_${System.currentTimeMillis()}.jpg")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
        }
        file.absolutePath
    } catch (e: Exception) {
        ""
    }
}

fun copyUriToInternalStorage(context: Context, uri: Uri): String {
    return try {
        val dir = File(context.filesDir, "student_photos").apply { if (!exists()) mkdirs() }
        val file = File(dir, "student_${System.currentTimeMillis()}.jpg")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(file).use { output ->
                input.copyTo(output)
            }
        }
        file.absolutePath
    } catch (e: Exception) {
        uri.toString()
    }
}

fun getNextStudentId(students: List<StudentEntity>): String {
    val nums = students.mapNotNull { student ->
        Regex("\\d+").find(student.id)?.value?.toIntOrNull()
    }
    val nextNum = if (nums.isEmpty()) 1 else (nums.maxOrNull() ?: 0) + 1
    return "STU%03d".format(nextNum)
}

// ----------------------------------------------------
// 1. New Registration Section
// ----------------------------------------------------
@Composable
fun AdminRegisterSection(viewModel: AttendanceViewModel) {
    val allStudents by viewModel.allStudents.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var regId by remember { mutableStateOf("") }
    var regName by remember { mutableStateOf("") }
    var regGrade by remember { mutableStateOf("10 ශ්‍රේණිය") }
    var regGender by remember { mutableStateOf("male") }
    var regDob by remember { mutableStateOf("2010-05-15") }
    var regWhatsapp by remember { mutableStateOf("") }
    var regPhotoPath by remember { mutableStateOf("") }
    var isFingerprintRegistered by remember { mutableStateOf(false) }
    var isScanningFp by remember { mutableStateOf(false) }
    var fpScanCount by remember { mutableIntStateOf(0) }
    var isFpScanning by remember { mutableStateOf(false) }

    // Last registered student to prominently display details
    var lastRegisteredStudent by remember { mutableStateOf<StudentEntity?>(null) }

    // Live identify student by ID
    val identifiedStudent = remember(regId, allStudents) {
        if (regId.isNotBlank()) allStudents.find { it.id.equals(regId.trim(), ignoreCase = true) } else null
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val savedPath = copyUriToInternalStorage(context, uri)
            if (savedPath.isNotBlank()) {
                regPhotoPath = savedPath
                Toast.makeText(context, "ඡායාරූපය සාර්ථකව එකතු විය!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        if (bitmap != null) {
            val savedPath = saveBitmapToInternalStorage(context, bitmap)
            if (savedPath.isNotBlank()) {
                regPhotoPath = savedPath
                Toast.makeText(context, "කැමරා ඡායාරූපය සාර්ථකව ලබා ගන්නා ලදී!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            cameraLauncher.launch(null)
        } else {
            Toast.makeText(context, "කැමරාව භාවිතයට අවසරය අවශ්‍යයි (Camera permission needed)", Toast.LENGTH_LONG).show()
        }
    }

    val grades = listOf(
        "1 ශ්‍රේණිය", "2 ශ්‍රේණිය", "3 ශ්‍රේණිය", "4 ශ්‍රේණිය", "5 ශ්‍රේණිය",
        "6 ශ්‍රේණිය", "7 ශ්‍රේණිය", "8 ශ්‍රේණිය", "9 ශ්‍රේණිය", "10 ශ්‍රේණිය",
        "11 ශ්‍රේණිය", "12 ශ්‍රේණිය", "13 ශ්‍රේණිය"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_register_section"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Banner with Icon & Badge
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFFF8FAFC),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(SchoolPrimary.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PersonAdd,
                            contentDescription = null,
                            tint = SchoolPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "නව සිසු ලියාපදිංචිය",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = SlateDark,
                            maxLines = 1
                        )
                        Text(
                            text = "ශිෂ්‍ය තොරතුරු, ඡායාරූපය සහ ඇඟිලි සලකුණු",
                            fontSize = 11.sp,
                            color = SlateMuted,
                            maxLines = 1
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = SchoolPrimary
                    ) {
                        Text(
                            text = "සිසුන්: ${allStudents.size}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // 1. 🆔 Student ID input + Auto ID generation button
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "🆔 සිසු හැඳුනුම් අංකය (Student ID) *",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = SlateDark
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = regId,
                        onValueChange = { regId = it.uppercase() },
                        placeholder = { Text("උදා: STU001", fontSize = 13.sp) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Badge,
                                contentDescription = null,
                                tint = SchoolPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("reg_id_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    Button(
                        onClick = {
                            regId = getNextStudentId(allStudents)
                            Toast.makeText(context, "ඊළඟ ID අංකය ලබා දෙන ලදී: $regId", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .height(54.dp)
                            .testTag("auto_id_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SchoolPrimary)
                    ) {
                        Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ඊළඟ ID", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // If Student Identified by ID
                if (identifiedStudent != null) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFFEF3C7),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF59E0B))
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = Color(0xFFD97706),
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = "🔍 සිසුවා හඳුනාගන්නා ලදී: ${identifiedStudent.name} (${identifiedStudent.grade})",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF92400E)
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        regName = identifiedStudent.name
                                        regGrade = identifiedStudent.grade
                                        regGender = identifiedStudent.gender
                                        regDob = identifiedStudent.dob
                                        regWhatsapp = identifiedStudent.whatsapp
                                        regPhotoPath = identifiedStudent.photo
                                        val hasFp = identifiedStudent.faceData.isNotBlank()
                                        isFingerprintRegistered = hasFp
                                        fpScanCount = if (hasFp) 5 else 0
                                        Toast.makeText(context, "දත්ත පූරණය විය!", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706))
                                ) {
                                    Text("විස්තර ලබාගන්න (Load)", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = {
                                        regId = getNextStudentId(allStudents)
                                        fpScanCount = 0
                                        isFingerprintRegistered = false
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("නව ID ගන්න", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // 2. 👤 Student Full Name
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "👤 සිසුවාගේ සම්පූර්ණ නම (Full Name) *",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = SlateDark
                )
                OutlinedTextField(
                    value = regName,
                    onValueChange = { regName = it },
                    placeholder = { Text("උදා: සදරුවන් පෙරේරා", fontSize = 13.sp) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = SchoolPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reg_name_input"),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )
            }

            // 3. Grade & Gender side-by-side
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Grade Selector
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "🎓 ශ්‍රේණිය *",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SlateDark
                    )
                    var gradeExpanded by remember { mutableStateOf(false) }
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { gradeExpanded = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = SlateDark),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1))
                        ) {
                            Icon(
                                Icons.Default.School,
                                contentDescription = null,
                                tint = SchoolPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = regGrade,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }
                        DropdownMenu(
                            expanded = gradeExpanded,
                            onDismissRequest = { gradeExpanded = false }
                        ) {
                            grades.forEach { grade ->
                                DropdownMenuItem(
                                    text = { Text(grade) },
                                    onClick = {
                                        regGrade = grade
                                        gradeExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Gender Segmented Buttons
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "⚧ ස්ත්‍රී / පුරුෂ *",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SlateDark
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { regGender = "male" }
                                .testTag("gender_male_btn"),
                            color = if (regGender == "male") BoysBlueLight else Color(0xFFF1F5F9),
                            border = androidx.compose.foundation.BorderStroke(
                                1.5.dp,
                                if (regGender == "male") BoysBlue else Color(0xFFE2E8F0)
                            )
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    "👦 පිරිමි",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (regGender == "male") BoysBlue else SlateDark
                                )
                            }
                        }

                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { regGender = "female" }
                                .testTag("gender_female_btn"),
                            color = if (regGender == "female") GirlsPinkLight else Color(0xFFF1F5F9),
                            border = androidx.compose.foundation.BorderStroke(
                                1.5.dp,
                                if (regGender == "female") GirlsPink else Color(0xFFE2E8F0)
                            )
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    "👧 ගැහැණු",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (regGender == "female") GirlsPink else SlateDark
                                )
                            }
                        }
                    }
                }
            }

            // 4. DOB & WhatsApp side-by-side
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "🎂 උපන්දිනය",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SlateDark
                    )
                    OutlinedTextField(
                        value = regDob,
                        onValueChange = { regDob = it },
                        placeholder = { Text("YYYY-MM-DD", fontSize = 12.sp) },
                        leadingIcon = {
                            Icon(
                                Icons.Default.Cake,
                                contentDescription = null,
                                tint = SchoolPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                Column(
                    modifier = Modifier.weight(1.2f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "📱 WhatsApp අංකය",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SlateDark
                    )
                    OutlinedTextField(
                        value = regWhatsapp,
                        onValueChange = { regWhatsapp = it },
                        placeholder = { Text("0771234567", fontSize = 12.sp) },
                        leadingIcon = {
                            Icon(
                                Icons.Default.PhoneAndroid,
                                contentDescription = null,
                                tint = SchoolPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reg_whatsapp_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }

            // 5. 📸 Student Photo Section: Camera + Upload from Gallery
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("student_photo_picker_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "📸 සිසුවාගේ ඡායාරූපය (Student Photo)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = SlateDark
                        )
                        if (regPhotoPath.isNotBlank()) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = SchoolAccentGreen.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "✓ ඡායාරූපය ඇත",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SchoolAccentGreen,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Avatar preview frame
                        Box(
                            modifier = Modifier
                                .size(92.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (regGender == "female") GirlsPinkLight else BoysBlueLight)
                                .border(
                                    2.dp,
                                    if (regPhotoPath.isNotBlank()) SchoolAccentGreen else Color(0xFFCBD5E1),
                                    RoundedCornerShape(16.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (regPhotoPath.isNotBlank()) {
                                AsyncImage(
                                    model = File(regPhotoPath).let { if (it.exists()) it else regPhotoPath },
                                    contentDescription = "Student Photo",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AddAPhoto,
                                        contentDescription = null,
                                        tint = SlateMuted,
                                        modifier = Modifier.size(28.dp)
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "ඡායාරූපයක්\nනැත",
                                        fontSize = 10.sp,
                                        color = SlateMuted,
                                        textAlign = TextAlign.Center,
                                        lineHeight = 12.sp
                                    )
                                }
                            }
                        }

                        // Photo options: Camera + Upload Gallery
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    val hasCamera = ContextCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.CAMERA
                                    ) == PackageManager.PERMISSION_GRANTED
                                    if (hasCamera) {
                                        cameraLauncher.launch(null)
                                    } else {
                                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(42.dp)
                                    .testTag("take_photo_camera_button"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = SchoolPrimary)
                            ) {
                                Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("📸 කැමරාවෙන් ගන්න", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(42.dp)
                                    .testTag("upload_photo_gallery_button"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = SchoolPrimary),
                                border = androidx.compose.foundation.BorderStroke(1.dp, SchoolPrimary.copy(alpha = 0.5f))
                            ) {
                                Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("🖼️ ගැලරියෙන් තෝරන්න", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            if (regPhotoPath.isNotBlank()) {
                                TextButton(
                                    onClick = { regPhotoPath = "" },
                                    modifier = Modifier.height(28.dp),
                                    colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFEF4444))
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("ඡායාරූපය ඉවත් කරන්න", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }

            // 6. 5-Step Biometric Fingerprint Enrollment & Verification
            Fingerprint5StepEnrollmentCard(
                scanCount = fpScanCount,
                isScanning = isFpScanning,
                onScanTap = {
                    if (fpScanCount < 5) {
                        coroutineScope.launch {
                            isFpScanning = true
                            kotlinx.coroutines.delay(650)
                            isFpScanning = false
                            fpScanCount++
                            if (fpScanCount >= 5) {
                                isFingerprintRegistered = true
                                Toast.makeText(
                                    context,
                                    "✅ ඇඟිලි සලකුණ 5 වතාවක් තහවුරු කර 100% ආරක්ෂිතව ගබඩා කරන ලදී!",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    }
                },
                onResetTap = {
                    fpScanCount = 0
                    isFingerprintRegistered = false
                }
            )

            // 7. Live Student Identity Card Preview
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("student_id_preview_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F5F9)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1))
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "💳 හැඳුනුම්පත් පෙරදසුන (Identity Preview)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = SlateDark
                        )
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SchoolPrimary.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = regId.ifBlank { "STU---" },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = SchoolPrimary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(if (regGender == "female") GirlsPinkLight else BoysBlueLight),
                            contentAlignment = Alignment.Center
                        ) {
                            if (regPhotoPath.isNotBlank()) {
                                AsyncImage(
                                    model = File(regPhotoPath).let { if (it.exists()) it else regPhotoPath },
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Text(
                                    text = regName.take(1).ifBlank { "?" },
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (regGender == "female") GirlsPink else BoysBlue
                                )
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = regName.ifBlank { "සිසුවාගේ නම..." },
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = SlateDark
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(text = "🎓 $regGrade", fontSize = 11.sp, color = SlateMuted)
                                Text(
                                    text = if (regGender == "male") "👦 පිරිමි" else "👧 ගැහැණු",
                                    fontSize = 11.sp,
                                    color = if (regGender == "male") BoysBlue else GirlsPink,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            if (regWhatsapp.isNotBlank()) {
                                Text(text = "📱 $regWhatsapp", fontSize = 10.sp, color = SchoolAccentGreenDark)
                            }
                        }
                    }
                }
            }

            // 8. Submit Register Button
            Button(
                onClick = {
                    if (regId.isBlank() || regName.isBlank()) {
                        Toast.makeText(context, "කරුණාකර ID අංකය සහ නම ඇතුළත් කරන්න!", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    if (fpScanCount in 1..4) {
                        Toast.makeText(
                            context,
                            "⚠️ කරුණාකර ඇඟිලි සලකුණු තහවුරු කිරීමේ පියවර 5 ම සම්පූර්ණ කරන්න! (දැනට $fpScanCount/5)",
                            Toast.LENGTH_LONG
                        ).show()
                        return@Button
                    }
                    val newStudent = StudentEntity(
                        id = regId.trim().uppercase(),
                        name = regName.trim(),
                        grade = regGrade,
                        gender = regGender,
                        dob = regDob,
                        whatsapp = regWhatsapp.trim().ifBlank { "නැත" },
                        photo = regPhotoPath,
                        faceData = if (fpScanCount >= 5) "fp_5x_verified_${regId.trim().lowercase()}" else "",
                        registeredDate = AttendanceRepository.getTodayDateString()
                    )
                    viewModel.registerStudent(newStudent) {
                        lastRegisteredStudent = newStudent
                        regId = ""
                        regName = ""
                        regWhatsapp = ""
                        regPhotoPath = ""
                        isFingerprintRegistered = false
                        fpScanCount = 0
                        Toast.makeText(context, "සිසුවා සාර්ථකව ලියාපදිංචි කරන ලදී!", Toast.LENGTH_SHORT).show()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = SchoolAccentGreen),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("submit_register_student")
            ) {
                Icon(
                    imageVector = Icons.Default.HowToReg,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("සිසුවා පද්ධතියට ලියාපදිංචි කරන්න", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }

            // Post-Registration: Correctly identify & display student details prominently!
            if (lastRegisteredStudent != null) {
                val s = lastRegisteredStudent!!
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("registered_student_details_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                    border = androidx.compose.foundation.BorderStroke(2.dp, SchoolAccentGreen)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = SchoolAccentGreen,
                                modifier = Modifier.size(24.dp)
                            )
                            Text(
                                text = "🎉 සිසුවා සාර්ථකව හඳුනාගෙන ලියාපදිංචි කරන ලදී!",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = SchoolAccentGreenDark
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(76.dp)
                                    .clip(CircleShape)
                                    .background(if (s.gender == "female") GirlsPinkLight else BoysBlueLight)
                                    .border(3.dp, SchoolAccentGreen, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                if (s.photo.isNotBlank()) {
                                    AsyncImage(
                                        model = File(s.photo).let { if (it.exists()) it else s.photo },
                                        contentDescription = s.name,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Text(
                                        text = s.name.take(1),
                                        fontSize = 28.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (s.gender == "female") GirlsPink else BoysBlue
                                    )
                                }
                            }

                            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(
                                    text = s.name,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SlateDark
                                )
                                Text(
                                    text = "🆔 ${s.id} | 🎓 ${s.grade}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = SchoolPrimary
                                )
                                Text(
                                    text = "⚧ ${if (s.gender == "male") "පිරිමි (Male)" else "ගැහැණු (Female)"} | 🎂 ${s.dob}",
                                    fontSize = 11.sp,
                                    color = SlateMuted
                                )
                                Text(
                                    text = "📱 WhatsApp: ${s.whatsapp}",
                                    fontSize = 11.sp,
                                    color = SlateDark
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    viewModel.scanStudent(s.id)
                                    Toast.makeText(context, "${s.name} ගේ පැමිණීම සටහන් විය!", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = SchoolPrimary),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("⏱️ අද පැමිණීම සටහන් කරන්න", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = {
                                    lastRegisteredStudent = null
                                    regId = getNextStudentId(allStudents)
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("➕ තවත් සිසුවෙකු ලියාපදිංචිය", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// 2. Students List Section
// ----------------------------------------------------
@Composable
fun AdminStudentsSection(viewModel: AttendanceViewModel) {
    val students by viewModel.filteredStudents.collectAsStateWithLifecycle()
    val searchQuery by viewModel.studentSearchQuery.collectAsStateWithLifecycle()
    val editingStudent by viewModel.editingStudent.collectAsStateWithLifecycle()

    var studentToDelete by remember { mutableStateOf<StudentEntity?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setStudentSearchQuery(it) },
            placeholder = { Text("🔍 නම හෝ ID අංකය සොයන්න...") },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("student_search_input"),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) }
        )

        if (students.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier.padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(text = "👥", fontSize = 42.sp)
                    Text(text = "සිසුන් හමු නොවීය", fontWeight = FontWeight.Bold, color = SlateDark)
                }
            }
        } else {
            students.forEach { student ->
                StudentListItemCard(
                    student = student,
                    onEditClick = { viewModel.startEditingStudent(student) },
                    onDeleteClick = { studentToDelete = student }
                )
            }
        }
    }

    // Edit Student Dialog
    if (editingStudent != null) {
        EditStudentDialog(
            student = editingStudent!!,
            onDismiss = { viewModel.cancelEditingStudent() },
            onSave = { updated -> viewModel.saveEditedStudent(updated) }
        )
    }

    // Delete confirmation dialog
    if (studentToDelete != null) {
        AlertDialog(
            onDismissRequest = { studentToDelete = null },
            title = { Text("සිසුවා ඉවත් කිරීම") },
            text = { Text("${studentToDelete!!.name} (${studentToDelete!!.id}) මැකීමට ඔබට විශ්වාසද?") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteStudent(studentToDelete!!.id)
                    studentToDelete = null
                }) {
                    Text("ඔව්, මකන්න", color = Color(0xFFDC2626), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { studentToDelete = null }) {
                    Text("අවලංගු කරන්න")
                }
            }
        )
    }
}

@Composable
fun StudentListItemCard(
    student: StudentEntity,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("student_item_${student.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(if (student.gender == "female") GirlsPinkLight else BoysBlueLight)
                    .border(2.dp, if (student.gender == "female") GirlsPinkBorder else BoysBlueBorder, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (student.photo.isNotBlank()) {
                    AsyncImage(
                        model = File(student.photo).let { if (it.exists()) it else student.photo },
                        contentDescription = student.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Text(
                        text = student.name.take(1),
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        color = if (student.gender == "female") GirlsPink else BoysBlue
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = student.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = SlateDark
                )
                Text(
                    text = "🆔 ${student.id} | 🎓 ${student.grade}",
                    fontSize = 12.sp,
                    color = SlateMuted
                )
                if (student.whatsapp.isNotBlank() && student.whatsapp != "නැත") {
                    Text(
                        text = "📱 ${student.whatsapp}",
                        fontSize = 11.sp,
                        color = SchoolAccentGreenDark
                    )
                }
                if (student.faceData.isNotBlank()) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFFECFDF5),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFA7F3D0)),
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Fingerprint,
                                contentDescription = null,
                                tint = SchoolAccentGreen,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "✓ 5-Scan Verified",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = SchoolAccentGreen
                            )
                        }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(onClick = onEditClick, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit", tint = SchoolPrimaryLight)
                }
                IconButton(onClick = onDeleteClick, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF4444))
                }
            }
        }
    }
}

@Composable
fun Fingerprint5StepEnrollmentCard(
    scanCount: Int, // 0 to 5
    isScanning: Boolean,
    onScanTap: () -> Unit,
    onResetTap: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "fp_enroll_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val isCompleted = scanCount >= 5
    val qualityPercentage = (scanCount * 20).coerceIn(0, 100)

    val cardBorderColor = when {
        isCompleted -> SchoolAccentGreen
        scanCount > 0 -> Color(0xFFF59E0B)
        else -> SchoolPrimaryLight.copy(alpha = 0.6f)
    }

    val cardBgColor = when {
        isCompleted -> Color(0xFFF0FDF4)
        scanCount > 0 -> Color(0xFFFFFBEB)
        else -> Color(0xFFF8FAFC)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("fingerprint_enrollment_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = cardBgColor),
        border = androidx.compose.foundation.BorderStroke(2.dp, cardBorderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (isCompleted) SchoolAccentGreen.copy(alpha = 0.15f)
                                else if (scanCount > 0) Color(0xFFFEF3C7)
                                else Color(0xFFEFF6FF)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.Fingerprint,
                            contentDescription = null,
                            tint = if (isCompleted) SchoolAccentGreen else if (scanCount > 0) Color(0xFFD97706) else SchoolPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "ඇඟිලි සලකුණු 5-පියවර තහවුරු කිරීම",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = SlateDark
                        )
                        Text(
                            text = "5-Step Biometric Enrollment",
                            fontSize = 11.sp,
                            color = SlateMuted
                        )
                    }
                }

                // Progress Badge
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isCompleted) SchoolAccentGreen else if (scanCount > 0) Color(0xFFD97706) else Color(0xFF64748B),
                ) {
                    Text(
                        text = if (isCompleted) "✓ 100% (5/5)" else "$scanCount/5 ($qualityPercentage%)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Text(
                text = "නිරවද්‍යතාව තහවුරු කිරීමට එකම ඇඟිලි සලකුණ 5 වතාවක් ස්කෑන් කරන්න.",
                fontSize = 11.sp,
                color = SlateMuted,
                textAlign = TextAlign.Center
            )

            // Progress Bar
            LinearProgressIndicator(
                progress = { scanCount / 5f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = if (isCompleted) SchoolAccentGreen else if (scanCount > 0) Color(0xFFF59E0B) else SchoolPrimary,
                trackColor = Color(0xFFE2E8F0)
            )

            // 5 Segmented Step Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val stepNames = listOf("1. මැද", "2. එසවීම", "3. දාර", "4. කෙළවර", "5. අවසන්")
                for (i in 0 until 5) {
                    val stepDone = i < scanCount
                    val isCurrent = i == scanCount

                    Surface(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        color = when {
                            stepDone -> SchoolAccentGreen
                            isCurrent -> SchoolPrimary.copy(alpha = 0.12f)
                            else -> Color(0xFFE2E8F0)
                        },
                        border = if (isCurrent) androidx.compose.foundation.BorderStroke(1.5.dp, SchoolPrimary) else null
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            if (stepDone) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(12.dp)
                                )
                            } else {
                                Text(
                                    text = "${i + 1}",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (isCurrent) SchoolPrimary else Color(0xFF94A3B8)
                                )
                            }
                            Text(
                                text = stepNames[i],
                                fontSize = 9.sp,
                                fontWeight = if (isCurrent || stepDone) FontWeight.Bold else FontWeight.Normal,
                                color = if (stepDone) Color.White else if (isCurrent) SchoolPrimary else Color(0xFF64748B),
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            // Interactive Touch Sensor
            Box(
                modifier = Modifier
                    .size(92.dp)
                    .scale(if (isScanning) pulseScale else 1f)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = when {
                                isCompleted -> listOf(SchoolAccentGreen, Color(0xFF10B981))
                                scanCount > 0 -> listOf(Color(0xFFF59E0B), Color(0xFFD97706))
                                else -> listOf(SchoolPrimary, Color(0xFF2563EB))
                            }
                        )
                    )
                    .clickable(enabled = !isScanning && !isCompleted) { onScanTap() }
                    .testTag("fingerprint_enrollment_touch_pad"),
                contentAlignment = Alignment.Center
            ) {
                if (isCompleted) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Completed",
                        tint = Color.White,
                        modifier = Modifier.size(54.dp)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Fingerprint,
                        contentDescription = "Scan Fingerprint",
                        tint = Color.White,
                        modifier = Modifier.size(54.dp)
                    )
                }
            }

            // Step instructions
            val stepInstruction = when {
                isScanning -> "⏳ ස්කෑන් කරමින්... ඇඟිල්ල නිශ්චලව තබන්න..."
                isCompleted -> "🎉 ඇඟිලි සලකුණ 5 වතාවක් සාර්ථකව තහවුරු කර 100% ආරක්ෂිතව ගබඩා විය!"
                scanCount == 0 -> "👆 1 වන ස්කෑන් එක: ඇඟිල්ල ස්කෑනරය මධ්‍යයේ තබන්න (Center Scan)"
                scanCount == 1 -> "👆 2 වන ස්කෑන් එක: ඇඟිල්ල මදක් ඔසවා නැවත ස්කෑනරය මත තබන්න (Lift & Replace)"
                scanCount == 2 -> "👆 3 වන ස්කෑන් එක: ඇඟිල්ලේ දාර ස්පර්ශ වන සේ තබන්න (Edge Capture)"
                scanCount == 3 -> "👆 4 වන ස්කෑන් එක: ඇඟිල්ලේ ඉහළ කෙළවර ස්කෑනරය මත තබන්න (Fingertip Scan)"
                scanCount == 4 -> "👆 5 වන ස්කෑන් එක: අවසන් තහවුරු කිරීම සඳහා ස්පර්ශ කරන්න (Final Verification)"
                else -> ""
            }

            Text(
                text = stepInstruction,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (isCompleted) SchoolAccentGreen else if (scanCount > 0) Color(0xFFB45309) else SlateDark,
                textAlign = TextAlign.Center
            )

            // Reset button if scanned at least once
            if (scanCount > 0) {
                OutlinedButton(
                    onClick = onResetTap,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("නැවත ස්කෑන් කරන්න (Reset)", fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun EditStudentDialog(
    student: StudentEntity,
    onDismiss: () -> Unit,
    onSave: (StudentEntity) -> Unit
) {
    val context = LocalContext.current
    val dialogScope = rememberCoroutineScope()
    var name by remember { mutableStateOf(student.name) }
    var grade by remember { mutableStateOf(student.grade) }
    var whatsapp by remember { mutableStateOf(student.whatsapp) }
    var photoPath by remember { mutableStateOf(student.photo) }
    var editFpScanCount by remember { mutableIntStateOf(if (student.faceData.isNotBlank()) 5 else 0) }
    var isEditFpScanning by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val savedPath = copyUriToInternalStorage(context, uri)
            if (savedPath.isNotBlank()) {
                photoPath = savedPath
            }
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        if (bitmap != null) {
            val savedPath = saveBitmapToInternalStorage(context, bitmap)
            if (savedPath.isNotBlank()) {
                photoPath = savedPath
            }
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            cameraLauncher.launch(null)
        } else {
            Toast.makeText(context, "කැමරා අවසරය අවශ්‍යයි (Camera permission needed)", Toast.LENGTH_SHORT).show()
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .heightIn(max = 580.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("✏️ සිසු විස්තර සංස්කරණය", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = SlateDark)

                // Photo preview and change buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFF1F5F9))
                            .border(1.dp, SlateBorder, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (photoPath.isNotBlank()) {
                            AsyncImage(
                                model = File(photoPath).let { if (it.exists()) it else photoPath },
                                contentDescription = null,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Icon(Icons.Default.Person, contentDescription = null, tint = SlateMuted)
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = {
                                    val hasCam = ContextCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.CAMERA
                                    ) == PackageManager.PERMISSION_GRANTED
                                    if (hasCam) cameraLauncher.launch(null)
                                    else cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Text("📸 කැමරා", fontSize = 11.sp)
                            }

                            OutlinedButton(
                                onClick = {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Text("🖼️ ගැලරි", fontSize = 11.sp)
                            }
                        }
                        if (photoPath.isNotBlank()) {
                            TextButton(
                                onClick = { photoPath = "" },
                                contentPadding = PaddingValues(0.dp),
                                modifier = Modifier.height(24.dp)
                            ) {
                                Text("ඡායාරූපය ඉවත් කරන්න", fontSize = 10.sp, color = Color(0xFFEF4444))
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = student.id,
                    onValueChange = {},
                    label = { Text("ID අංකය") },
                    readOnly = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("නම") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = grade,
                    onValueChange = { grade = it },
                    label = { Text("ශ්‍රේණිය") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = whatsapp,
                    onValueChange = { whatsapp = it },
                    label = { Text("WhatsApp අංකය") },
                    modifier = Modifier.fillMaxWidth()
                )

                // 5-Step Biometric Fingerprint Enrollment & Verification
                Fingerprint5StepEnrollmentCard(
                    scanCount = editFpScanCount,
                    isScanning = isEditFpScanning,
                    onScanTap = {
                        if (editFpScanCount < 5) {
                            dialogScope.launch {
                                isEditFpScanning = true
                                kotlinx.coroutines.delay(650)
                                isEditFpScanning = false
                                editFpScanCount++
                                if (editFpScanCount >= 5) {
                                    Toast.makeText(
                                        context,
                                        "✅ ඇඟිලි සලකුණ 5 වතාවක් තහවුරු කර 100% ආරක්ෂිතව ගබඩා කරන ලදී!",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                        }
                    },
                    onResetTap = {
                        editFpScanCount = 0
                    }
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("අවලංගු කරන්න")
                    }
                    Button(
                        onClick = {
                            if (editFpScanCount in 1..4) {
                                Toast.makeText(
                                    context,
                                    "⚠️ කරුණාකර ඇඟිලි සලකුණු තහවුරු කිරීමේ පියවර 5 ම සම්පූර්ණ කරන්න! (දැනට $editFpScanCount/5)",
                                    Toast.LENGTH_LONG
                                ).show()
                                return@Button
                            }
                            val updatedFaceData = if (editFpScanCount >= 5) "fp_5x_verified_${student.id.trim().lowercase()}" else ""
                            onSave(
                                student.copy(
                                    name = name,
                                    grade = grade,
                                    whatsapp = whatsapp,
                                    photo = photoPath,
                                    faceData = updatedFaceData
                                )
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SchoolPrimary)
                    ) {
                        Text("සුරකින්න")
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// 3. Attendance Reports Section
// ----------------------------------------------------
@Composable
fun AdminAttendanceReportsSection(viewModel: AttendanceViewModel) {
    val viewMode by viewModel.reportViewMode.collectAsStateWithLifecycle()
    val dailyDate by viewModel.selectedDailyDate.collectAsStateWithLifecycle()
    val monthlyDate by viewModel.selectedMonthlyDate.collectAsStateWithLifecycle()
    val yearlyDate by viewModel.selectedYearlyDate.collectAsStateWithLifecycle()

    val records by viewModel.todayAttendance.collectAsStateWithLifecycle()

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Tab Pills
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ReportModeTab(
                text = "📅 දෛනික",
                selected = viewMode == ReportViewMode.DAILY,
                onClick = { viewModel.setReportViewMode(ReportViewMode.DAILY) },
                modifier = Modifier.weight(1f)
            )
            ReportModeTab(
                text = "📆 මාසික",
                selected = viewMode == ReportViewMode.MONTHLY,
                onClick = { viewModel.setReportViewMode(ReportViewMode.MONTHLY) },
                modifier = Modifier.weight(1f)
            )
            ReportModeTab(
                text = "📊 වාර්ෂික",
                selected = viewMode == ReportViewMode.YEARLY,
                onClick = { viewModel.setReportViewMode(ReportViewMode.YEARLY) },
                modifier = Modifier.weight(1f)
            )
        }

        // Summary Cards
        val totalPresent = records.size
        val onTimeCount = records.count { it.isOnTime }
        val lateCount = totalPresent - onTimeCount

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SummarySmallCard("මුළු පැමිණීම්", totalPresent.toString(), BoysBlue, Modifier.weight(1f))
            SummarySmallCard("නියමිත", onTimeCount.toString(), SchoolAccentGreen, Modifier.weight(1f))
            SummarySmallCard("ප්‍රමාද", lateCount.toString(), LateOrange, Modifier.weight(1f))
        }

        Text(
            text = "📋 පැමිණි සිසුන් ලැයිස්තුව ($dailyDate)",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = SlateDark
        )

        if (records.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(text = "📅", fontSize = 36.sp)
                    Text(text = "අද දිනට පැමිණීම් සටහන් වී නැත", color = SlateMuted)
                }
            }
        } else {
            records.sortedBy { it.timestamp }.forEach { record ->
                AttendanceItemRow(record)
            }
        }
    }
}

@Composable
fun ReportModeTab(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() },
        color = if (selected) SchoolPrimary else Color(0xFFF1F5F9),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) SchoolPrimary else SlateBorder)
    ) {
        Box(
            modifier = Modifier.padding(vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = text,
                color = if (selected) Color.White else SlateDark,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
fun SummarySmallCard(
    label: String,
    value: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(text = value, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = accentColor)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = label, fontSize = 11.sp, color = SlateMuted, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

@Composable
fun AttendanceItemRow(record: AttendanceEntity) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(if (record.gender == "female") GirlsPinkLight else BoysBlueLight),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = record.studentName.take(1),
                    fontWeight = FontWeight.Bold,
                    color = if (record.gender == "female") GirlsPink else BoysBlue
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(text = record.studentName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SlateDark)
                Text(text = "🆔 ${record.studentId} | 🎓 ${record.grade}", fontSize = 11.sp, color = SlateMuted)
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (record.isOnTime) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (record.isOnTime) Color(0xFF22C55E) else Color(0xFFEF4444))
            ) {
                Text(
                    text = "🕐 ${record.time}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (record.isOnTime) Color(0xFF15803D) else Color(0xFFB91C1C),
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

// ----------------------------------------------------
// 4. Grade Reports Section
// ----------------------------------------------------
@Composable
fun AdminGradeReportsSection(viewModel: AttendanceViewModel) {
    val selectedGrade by viewModel.selectedGrade.collectAsStateWithLifecycle()
    val allStudents by viewModel.allStudents.collectAsStateWithLifecycle()
    val todayAttendance by viewModel.todayAttendance.collectAsStateWithLifecycle()

    val grades = listOf(
        "1 ශ්‍රේණිය", "2 ශ්‍රේණිය", "3 ශ්‍රේණිය", "4 ශ්‍රේණිය", "5 ශ්‍රේණිය",
        "6 ශ්‍රේණිය", "7 ශ්‍රේණිය", "8 ශ්‍රේණිය", "9 ශ්‍රේණිය", "10 ශ්‍රේණිය",
        "11 ශ්‍රේණිය", "12 ශ්‍රේණිය", "13 ශ්‍රේණිය"
    )

    val gradeStudents = allStudents.filter { it.grade == selectedGrade }
    val presentCount = todayAttendance.count { att -> gradeStudents.any { it.id == att.studentId } }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        var expanded by remember { mutableStateOf(false) }
        Box(modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(
                onClick = { expanded = true },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("🎓 $selectedGrade", fontWeight = FontWeight.Bold, color = SlateDark)
                Spacer(modifier = Modifier.weight(1f))
                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                grades.forEach { g ->
                    DropdownMenuItem(
                        text = { Text(g) },
                        onClick = {
                            viewModel.setSelectedGrade(g)
                            expanded = false
                        }
                    )
                }
            }
        }

        // Stats card for grade
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "$selectedGrade - පැමිණීම් සංඛ්‍යාලේඛන",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = SlateDark
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SummarySmallCard("මුළු සිසුන්", gradeStudents.size.toString(), BoysBlue, Modifier.weight(1f))
                    SummarySmallCard("අද පැමිණි", presentCount.toString(), SchoolAccentGreen, Modifier.weight(1f))
                    SummarySmallCard("නොපැමිණි", (gradeStudents.size - presentCount).coerceAtLeast(0).toString(), LateRed, Modifier.weight(1f))
                }
            }
        }

        Text("සිසු පැමිණීම් තොරතුරු", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = SlateDark)

        gradeStudents.forEachIndexed { index, student ->
            val record = todayAttendance.find { it.studentId == student.id }
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "${index + 1}",
                        fontWeight = FontWeight.Bold,
                        color = SlateMuted,
                        fontSize = 13.sp
                    )

                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = student.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SlateDark)
                        Text(text = "🆔 ${student.id}", fontSize = 11.sp, color = SlateMuted)
                    }

                    if (record != null) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (record.isOnTime) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (record.isOnTime) Color(0xFF22C55E) else Color(0xFFEF4444))
                        ) {
                            Text(
                                text = "🕐 ${record.time}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (record.isOnTime) Color(0xFF15803D) else Color(0xFFB91C1C),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    } else {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFF1F5F9),
                            border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
                        ) {
                            Text(
                                text = "❌ නැත",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = SlateMuted,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// 5. Individual Reports Section (WhatsApp Share)
// ----------------------------------------------------
@Composable
fun AdminIndividualReportsSection(viewModel: AttendanceViewModel) {
    val context = LocalContext.current
    val allStudents by viewModel.allStudents.collectAsStateWithLifecycle()
    val selectedId by viewModel.individualStudentId.collectAsStateWithLifecycle()
    val reportType by viewModel.individualReportType.collectAsStateWithLifecycle()
    val remarks by viewModel.individualRemarks.collectAsStateWithLifecycle()

    val selectedStudent = allStudents.find { it.id == selectedId }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Tips Banner
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = Color(0xFFEFF6FF),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBFDBFE))
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "💡", fontSize = 24.sp)
                Text(
                    text = "මෙම කොටසින් එක් සිසුවකුගේ පැමිණීම් වාර්තාව සකසා දෙමාපියන්ට WhatsApp මගින් යැවිය හැක.",
                    fontSize = 12.sp,
                    color = Color(0xFF1E40AF)
                )
            }
        }

        // Student selector
        Text("👨‍🎓 සිසුවා තෝරන්න *", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SlateDark)
        var studentMenuExpanded by remember { mutableStateOf(false) }
        Box(modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(
                onClick = { studentMenuExpanded = true },
                modifier = Modifier.fillMaxWidth().testTag("select_individual_student_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = selectedStudent?.let { "${it.name} (${it.id})" } ?: "සිසුවෙකු තෝරන්න...",
                    fontWeight = FontWeight.Bold,
                    color = if (selectedStudent != null) SlateDark else SlateMuted
                )
                Spacer(modifier = Modifier.weight(1f))
                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
            }
            DropdownMenu(
                expanded = studentMenuExpanded,
                onDismissRequest = { studentMenuExpanded = false }
            ) {
                allStudents.forEach { s ->
                    DropdownMenuItem(
                        text = { Text("${s.name} - ${s.id} (${s.grade})") },
                        onClick = {
                            viewModel.setIndividualStudentId(s.id)
                            studentMenuExpanded = false
                        }
                    )
                }
            }
        }

        if (selectedStudent != null) {
            // Student Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, SchoolPrimaryLight)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(if (selectedStudent.gender == "female") GirlsPinkLight else BoysBlueLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = selectedStudent.name.take(1),
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (selectedStudent.gender == "female") GirlsPink else BoysBlue
                        )
                    }

                    Column {
                        Text(text = selectedStudent.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = SlateDark)
                        Text(text = "🆔 ${selectedStudent.id} | 🎓 ${selectedStudent.grade}", fontSize = 12.sp, color = SlateMuted)
                        Text(
                            text = if (selectedStudent.whatsapp.isNotBlank() && selectedStudent.whatsapp != "නැත") "📱 ${selectedStudent.whatsapp}" else "⚠️ WhatsApp අංකයක් නැත",
                            fontSize = 11.sp,
                            color = if (selectedStudent.whatsapp.isNotBlank() && selectedStudent.whatsapp != "නැත") SchoolAccentGreenDark else Color(0xFFEF4444)
                        )
                    }
                }
            }

            // Report Type Selector
            Text("📊 වාර්තා වර්ගය *", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SlateDark)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ReportModeTab(
                    text = "දෛනික",
                    selected = reportType == "daily",
                    onClick = { viewModel.setIndividualReportType("daily") },
                    modifier = Modifier.weight(1f)
                )
                ReportModeTab(
                    text = "මාසික",
                    selected = reportType == "monthly",
                    onClick = { viewModel.setIndividualReportType("monthly") },
                    modifier = Modifier.weight(1f)
                )
                ReportModeTab(
                    text = "වාර්ෂික",
                    selected = reportType == "yearly",
                    onClick = { viewModel.setIndividualReportType("yearly") },
                    modifier = Modifier.weight(1f)
                )
            }

            // Remarks field
            OutlinedTextField(
                value = remarks,
                onValueChange = { viewModel.setIndividualRemarks(it) },
                label = { Text("👨‍🏫 ගුරුවරයාගේ පණිවිඩය (Teacher Remarks)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
                    .testTag("individual_remarks_input"),
                shape = RoundedCornerShape(12.dp)
            )

            // WhatsApp Share Button
            Button(
                onClick = { viewModel.shareIndividualReportViaWhatsApp(context) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("whatsapp_share_button")
            ) {
                Text(text = "📱", fontSize = 20.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "WhatsApp මගින් දෙමාපියන්ට යවන්න",
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 14.sp
                )
            }
        }
    }
}

// ----------------------------------------------------
// 6. Settings Section
// ----------------------------------------------------
@Composable
fun AdminSettingsSection(viewModel: AttendanceViewModel) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    var schoolName by remember(settings) { mutableStateOf(settings.schoolName) }
    var schoolAddress by remember(settings) { mutableStateOf(settings.schoolAddress) }
    var schoolPhone by remember(settings) { mutableStateOf(settings.schoolPhone) }
    var schoolEmail by remember(settings) { mutableStateOf(settings.schoolEmail) }
    var schoolLogoUrl by remember(settings) { mutableStateOf(settings.schoolLogoUrl) }
    var morningStartTime by remember(settings) { mutableStateOf(settings.morningStartTime) }
    var cutoffTime by remember(settings) { mutableStateOf(settings.attendanceCutoffTime) }
    var lateCutoffTime by remember(settings) { mutableStateOf(settings.lateCutoffTime) }
    var schoolEndTime by remember(settings) { mutableStateOf(settings.schoolEndTime) }
    var password by remember(settings) { mutableStateOf(settings.adminPassword) }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Timetable Configuration Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("📅", fontSize = 20.sp)
                    Text(
                        "පාසල් කාලසටහන සහ වේලාවන් (School Timetable)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = SlateDark
                    )
                }

                Text(
                    "සිසුන්ගේ නිවැරදි පැමිණීම (On-Time) සහ ප්‍රමාද වීම (Late) ස්වයංක්‍රීයව ගණනය කිරීමට මෙම වේලාවන් භාවිතා වේ.",
                    fontSize = 11.sp,
                    color = SlateMuted
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = morningStartTime,
                        onValueChange = { morningStartTime = it },
                        label = { Text("🌅 උදෑසන ආරම්භය") },
                        placeholder = { Text("06:30") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("settings_morning_start_input"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = cutoffTime,
                        onValueChange = { cutoffTime = it },
                        label = { Text("⏰ සාමාන්‍ය සීමාව (On-Time)") },
                        placeholder = { Text("07:30") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("settings_cutoff_time_input"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = lateCutoffTime,
                        onValueChange = { lateCutoffTime = it },
                        label = { Text("⚠️ ප්‍රමාද සීමාව (Late)") },
                        placeholder = { Text("08:30") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("settings_late_cutoff_input"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = schoolEndTime,
                        onValueChange = { schoolEndTime = it },
                        label = { Text("🔔 පාසල විසිරෙන වේලාව") },
                        placeholder = { Text("13:30") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("settings_end_time_input"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("🏫 පාසල් මූලික තොරතුරු", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = SlateDark)

                // School Logo Preview Card
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFF8FAFC), RoundedCornerShape(12.dp))
                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .border(2.dp, Color(0xFF60A5FA), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        AsyncImage(
                            model = ImageRequest.Builder(LocalContext.current)
                                .data(if (schoolLogoUrl.isNotBlank()) schoolLogoUrl else R.drawable.app_logo)
                                .placeholder(R.drawable.app_logo)
                                .error(R.drawable.app_logo)
                                .crossfade(true)
                                .build(),
                            contentDescription = "School Logo Preview",
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(3.dp)
                                .clip(CircleShape),
                            contentScale = ContentScale.Fit
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "පාසල් ලාංඡනය (School Logo)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = SlateDark
                        )
                        Text(
                            text = "යෙදුමේ ප්‍රධාන ශීර්ෂය සහ කාඩ්පත් මත දිස්වන නිල ලාංඡනය",
                            fontSize = 11.sp,
                            color = SlateMuted
                        )
                    }
                }

                OutlinedTextField(
                    value = schoolLogoUrl,
                    onValueChange = { schoolLogoUrl = it },
                    label = { Text("පාසල් ලාංඡන සබැඳිය (Logo Image URL)") },
                    modifier = Modifier.fillMaxWidth().testTag("settings_school_logo_url_input"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = schoolName,
                    onValueChange = { schoolName = it },
                    label = { Text("පාසල් නම *") },
                    modifier = Modifier.fillMaxWidth().testTag("settings_school_name_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = schoolAddress,
                    onValueChange = { schoolAddress = it },
                    label = { Text("පාසල් ලිපිනය") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = schoolPhone,
                    onValueChange = { schoolPhone = it },
                    label = { Text("සම්බන්ධතා අංකය") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("🔐 ගුරු මුරපදය (Admin Password)") },
                    modifier = Modifier.fillMaxWidth().testTag("settings_password_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                Button(
                    onClick = {
                        viewModel.saveSettings(
                            settings.copy(
                                schoolName = schoolName,
                                schoolAddress = schoolAddress,
                                schoolPhone = schoolPhone,
                                schoolLogoUrl = schoolLogoUrl,
                                morningStartTime = morningStartTime,
                                attendanceCutoffTime = cutoffTime,
                                lateCutoffTime = lateCutoffTime,
                                schoolEndTime = schoolEndTime,
                                adminPassword = password
                            )
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SchoolPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_settings_button")
                ) {
                    Text("💾 සැකසුම් සුරකින්න", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Test Data & Reset Actions
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("🧪 පරීක්ෂණ දත්ත සහ මෙවලම්", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = SlateDark)

                OutlinedButton(
                    onClick = { viewModel.generateSampleData() },
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("add_sample_data_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = SchoolAccentGreenDark)
                ) {
                    Icon(Icons.Default.AddCircle, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("ටෙස්ට් පැමිණීම් දත්ත එකතු කරන්න (Add Test Data)", fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = { viewModel.clearAllAttendance() },
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("clear_attendance_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626))
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("සියලු පැමිණීම් දත්ත මකන්න (Clear Attendance)", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
