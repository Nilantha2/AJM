package com.example.studentattendance.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.studentattendance.R
import com.example.studentattendance.ui.theme.*
import com.example.studentattendance.ui.viewmodel.AttendanceViewModel

@Composable
fun AdminLoginScreen(
    viewModel: AttendanceViewModel,
    modifier: Modifier = Modifier
) {
    val passwordInput by viewModel.adminPasswordInput.collectAsState()
    val isPasswordVisible by viewModel.adminPasswordVisible.collectAsState()
    val loginError by viewModel.adminLoginError.collectAsState()

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp)
            .testTag("admin_login_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // School Logo inside Login
            Box(
                modifier = Modifier
                    .size(82.dp)
                    .clip(CircleShape)
                    .background(Color.White)
                    .border(2.5.dp, Color(0xFF60A5FA), CircleShape)
                    .shadow(6.dp, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(R.drawable.app_logo)
                        .crossfade(true)
                        .build(),
                    contentDescription = "School Logo",
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(5.dp)
                        .clip(CircleShape),
                    contentScale = ContentScale.Fit
                )
            }

            Text(
                text = "ගුරු ප්‍රවේශය",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = SlateDark
            )

            Text(
                text = "නව සිසුන් ලියාපදිංචි කිරීමට සහ පරිපාලන කටයුතු සඳහා මුරපදය ඇතුළත් කරන්න",
                fontSize = 13.sp,
                color = SlateMuted,
                textAlign = TextAlign.Center
            )

            OutlinedTextField(
                value = passwordInput,
                onValueChange = { viewModel.setAdminPasswordInput(it) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_password_input"),
                label = { Text("මුරපදය (Password)") },
                singleLine = true,
                visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(
                        onClick = { viewModel.togglePasswordVisibility() },
                        modifier = Modifier.testTag("toggle_password_visibility")
                    ) {
                        Icon(
                            imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Toggle password"
                        )
                    }
                },
                shape = RoundedCornerShape(12.dp)
            )

            if (loginError != null) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFFEE2E2),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEF4444))
                ) {
                    Text(
                        text = loginError ?: "",
                        color = Color(0xFFDC2626),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }

            Button(
                onClick = { viewModel.adminLogin() },
                colors = ButtonDefaults.buttonColors(containerColor = SchoolPrimary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("admin_login_button")
            ) {
                Text(
                    text = "🔓 ඇතුල් වන්න (Login)",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFFEF3C7),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "💡", fontSize = 18.sp)
                    Text(
                        text = "\nපිටස්තර ප්‍රවේශ වීම් වලක්වා ගැනීමට මුරපදය ආරක්ෂිතව තබා ගන්න.",
                        fontSize = 11.sp,
                        color = Color(0xFF92400E)
                    )
                }
            }
        }
    }
}
