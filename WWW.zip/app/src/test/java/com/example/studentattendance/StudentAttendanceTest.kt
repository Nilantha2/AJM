package com.example.studentattendance

import com.example.studentattendance.data.repository.AttendanceRepository
import com.example.studentattendance.ui.viewmodel.AttendanceViewModel
import org.junit.Assert.*
import org.junit.Test
import java.util.Calendar

class StudentAttendanceTest {

    @Test
    fun testSinhalaDayNames() {
        assertEquals("ඉරිදා", AttendanceRepository.getSinhalaDayName(Calendar.SUNDAY))
        assertEquals("සඳුදා", AttendanceRepository.getSinhalaDayName(Calendar.MONDAY))
        assertEquals("අඟහරුවාදා", AttendanceRepository.getSinhalaDayName(Calendar.TUESDAY))
        assertEquals("බදාදා", AttendanceRepository.getSinhalaDayName(Calendar.WEDNESDAY))
        assertEquals("බ්‍රහස්පතින්දා", AttendanceRepository.getSinhalaDayName(Calendar.THURSDAY))
        assertEquals("සිකුරාදා", AttendanceRepository.getSinhalaDayName(Calendar.FRIDAY))
        assertEquals("සෙනසුරාදා", AttendanceRepository.getSinhalaDayName(Calendar.SATURDAY))
    }

    @Test
    fun testDateFormatting() {
        val today = AttendanceRepository.getTodayDateString()
        assertNotNull(today)
        assertTrue(today.matches(Regex("\\d{4}-\\d{2}-\\d{2}")))
    }

    @Test
    fun testCutoffCalculationLogic() {
        // Cutoff is 07:30
        val cutoffHour = 7
        val cutoffMin = 30

        // Test 07:15 -> On time
        val time1 = "07:15".split(":")
        val h1 = time1[0].toInt()
        val m1 = time1[1].toInt()
        val isOnTime1 = (h1 < cutoffHour) || (h1 == cutoffHour && m1 < cutoffMin)
        assertTrue(isOnTime1)

        // Test 07:35 -> Late
        val time2 = "07:35".split(":")
        val h2 = time2[0].toInt()
        val m2 = time2[1].toInt()
        val isOnTime2 = (h2 < cutoffHour) || (h2 == cutoffHour && m2 < cutoffMin)
        assertFalse(isOnTime2)

        // Test 06:55 -> On time
        val time3 = "06:55".split(":")
        val h3 = time3[0].toInt()
        val m3 = time3[1].toInt()
        val isOnTime3 = (h3 < cutoffHour) || (h3 == cutoffHour && m3 < cutoffMin)
        assertTrue(isOnTime3)
    }
}
